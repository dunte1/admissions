<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}" class="h-full">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="description" content="{{ system_setting('tagline', 'Streamline Admissions for Schools, Colleges & Universities') }}">
    <title>@yield('title', system_setting('system_name', 'Admission Portal') . ' - Admission Portal')</title>
    <link rel="icon" href="{{ app_favicon() }}">
    @vite(['resources/css/app.css', 'resources/js/app.js'])
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { font-family: 'Inter', sans-serif; }
        :root {
            --primary-color: {{ system_setting('primary_color', '#7C3AED') }};
            --secondary-color: {{ system_setting('secondary_color', '#10B981') }};
        }
        html { scroll-behavior: smooth; }
        [x-cloak] { display: none !important; }
    </style>
    @stack('styles')
</head>
<body class="h-full">
    @yield('content')
    <script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
    <x-ai-chat-widget mode="sales" />
    @stack('scripts')
</body>
</html>
