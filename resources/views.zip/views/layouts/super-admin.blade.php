<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}" class="h-full">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Super Admin - ' . system_setting('system_name', 'Admission Portal'))</title>
    <link rel="icon" href="{{ app_favicon() }}">
    @vite(['resources/css/app.css', 'resources/js/app.js'])
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        body { font-family: 'Inter', sans-serif; }
        ::-webkit-scrollbar { width: 6px; height: 6px; }
        ::-webkit-scrollbar-track { background: #f1f5f9; }
        ::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 3px; }
        ::-webkit-scrollbar-thumb:hover { background: #94a3b8; }
        .sidebar-transition { transition: width 0.3s ease, transform 0.3s ease; }
        [x-cloak] { display: none !important; }
    </style>
    @stack('styles')
</head>
<body class="h-full bg-gray-100">
    {{-- Fixed Sidebar --}}
    <aside id="sidebar" class="sidebar-transition fixed inset-y-0 left-0 z-40 w-64 bg-gray-900 border-r border-gray-700 flex flex-col shadow-xl overflow-hidden">
        <div class="h-14 sm:h-16 flex items-center justify-between px-3 sm:px-4 border-b border-gray-700" style="background: linear-gradient(to right, {{ system_setting('primary_color', '#00008B') }}, {{ system_setting('secondary_color', '#10B981') }})">
            <div class="flex items-center space-x-2 sm:space-x-3">
                <div class="w-8 sm:w-10 h-8 sm:h-10 bg-white rounded-lg flex items-center justify-center overflow-hidden flex-shrink-0">
                    @if(system_setting('system_logo'))
                        <img src="{{ asset('storage/' . system_setting('system_logo')) }}" alt="Logo" class="w-6 sm:w-8 h-6 sm:h-8 object-contain">
                    @else
                        <i class="fas fa-graduation-cap text-sm sm:text-xl" style="color: {{ system_setting('primary_color', '#00008B') }}"></i>
                    @endif
                </div>
                <div class="hidden sidebar-expanded:block">
                    <h1 class="text-white font-bold text-sm sm:text-lg leading-tight truncate max-w-[100px] sm:max-w-none">{{ app_name() }}</h1>
                </div>
            </div>
            <button id="closeSidebar" class="lg:hidden text-white hover:text-blue-200 p-1">
                <svg class="w-5 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                </svg>
            </button>
        </div>
        
        {{-- Navigation --}}
        <nav class="flex-1 py-4 overflow-y-auto">
            <div class="px-3 mb-2">
                <p class="px-4 text-xs font-semibold text-gray-400 uppercase tracking-wider">Main Menu</p>
            </div>
            
            <div class="space-y-1 px-3">
                <a href="{{ route('super-admin.dashboard') }}" class="nav-link flex items-center px-4 py-3 rounded-lg transition-all duration-200 {{ request()->routeIs('super-admin.dashboard') ? 'bg-[#00008B] text-white shadow-md' : 'text-gray-300 hover:bg-gray-800 hover:text-white' }}">
                    <i class="fas fa-home w-6 text-center"></i>
                    <span class="sidebar-text ml-3 font-medium">Dashboard</span>
                </a>
                
                <a href="{{ route('super-admin.schools.index') }}" class="nav-link flex items-center px-4 py-3 rounded-lg transition-all duration-200 {{ request()->routeIs('super-admin.schools.*') ? 'bg-[#00008B] text-white shadow-md' : 'text-gray-300 hover:bg-gray-800 hover:text-white' }}">
                    <i class="fas fa-building w-6 text-center"></i>
                    <span class="sidebar-text ml-3 font-medium">Schools</span>
                </a>
                
                <a href="{{ route('super-admin.applications.index') }}" class="nav-link flex items-center px-4 py-3 rounded-lg transition-all duration-200 {{ request()->routeIs('super-admin.applications.*') ? 'bg-[#00008B] text-white shadow-md' : 'text-gray-300 hover:bg-gray-800 hover:text-white' }}">
                    <i class="fas fa-file-alt w-6 text-center"></i>
                    <span class="sidebar-text ml-3 font-medium">Applications</span>
                </a>
                
                <a href="{{ route('super-admin.programs.index') }}" class="nav-link flex items-center px-4 py-3 rounded-lg transition-all duration-200 {{ request()->routeIs('super-admin.programs.*') ? 'bg-[#00008B] text-white shadow-md' : 'text-gray-300 hover:bg-gray-800 hover:text-white' }}">
                    <i class="fas fa-graduation-cap w-6 text-center"></i>
                    <span class="sidebar-text ml-3 font-medium">Programs</span>
                </a>
                
                <a href="{{ route('super-admin.users.index') }}" class="nav-link flex items-center px-4 py-3 rounded-lg transition-all duration-200 {{ request()->routeIs('super-admin.users.*') ? 'bg-[#00008B] text-white shadow-md' : 'text-gray-300 hover:bg-gray-800 hover:text-white' }}">
                    <i class="fas fa-users w-6 text-center"></i>
                    <span class="sidebar-text ml-3 font-medium">Users</span>
                </a>
            </div>
            
            <div class="px-3 mt-6 mb-2">
                <p class="px-4 text-xs font-semibold text-gray-400 uppercase tracking-wider">Reports</p>
            </div>
            
            <div class="space-y-1 px-3">
                <a href="{{ route('super-admin.reports.analytics') }}" class="nav-link flex items-center px-4 py-3 rounded-lg transition-all duration-200 {{ request()->routeIs('super-admin.reports.analytics') ? 'bg-[#00008B] text-white shadow-md' : 'text-gray-300 hover:bg-gray-800 hover:text-white' }}">
                    <i class="fas fa-chart-line w-6 text-center"></i>
                    <span class="sidebar-text ml-3 font-medium">Analytics</span>
                </a>
                
                <a href="{{ route('super-admin.reports.applications') }}" class="nav-link flex items-center px-4 py-3 rounded-lg transition-all duration-200 {{ request()->routeIs('super-admin.reports.applications') ? 'bg-[#00008B] text-white shadow-md' : 'text-gray-300 hover:bg-gray-800 hover:text-white' }}">
                    <i class="fas fa-file-signature w-6 text-center"></i>
                    <span class="sidebar-text ml-3 font-medium">Applications Report</span>
                </a>
                
                <a href="{{ route('super-admin.reports.payments') }}" class="nav-link flex items-center px-4 py-3 rounded-lg transition-all duration-200 {{ request()->routeIs('super-admin.reports.payments') ? 'bg-[#00008B] text-white shadow-md' : 'text-gray-300 hover:bg-gray-800 hover:text-white' }}">
                    <i class="fas fa-money-bill-wave w-6 text-center"></i>
                    <span class="sidebar-text ml-3 font-medium">Payments Report</span>
                </a>
                
                <a href="{{ route('super-admin.reports.schools') }}" class="nav-link flex items-center px-4 py-3 rounded-lg transition-all duration-200 {{ request()->routeIs('super-admin.reports.schools') ? 'bg-[#00008B] text-white shadow-md' : 'text-gray-300 hover:bg-gray-800 hover:text-white' }}">
                    <i class="fas fa-school w-6 text-center"></i>
                    <span class="sidebar-text ml-3 font-medium">Schools Report</span>
                </a>
                
                <a href="{{ route('super-admin.reports.users') }}" class="nav-link flex items-center px-4 py-3 rounded-lg transition-all duration-200 {{ request()->routeIs('super-admin.reports.users') ? 'bg-[#00008B] text-white shadow-md' : 'text-gray-300 hover:bg-gray-800 hover:text-white' }}">
                    <i class="fas fa-user-chart w-6 text-center"></i>
                    <span class="sidebar-text ml-3 font-medium">Users Report</span>
                </a>
            </div>
            
            <div class="px-3 mt-6 mb-2">
                <p class="px-4 text-xs font-semibold text-gray-400 uppercase tracking-wider">Subscription</p>
            </div>
            
            <div class="space-y-1 px-3">
                <a href="{{ route('super-admin.plans.index') }}" class="nav-link flex items-center px-4 py-3 rounded-lg transition-all duration-200 {{ request()->routeIs('super-admin.plans.*') ? 'bg-[#00008B] text-white shadow-md' : 'text-gray-300 hover:bg-gray-800 hover:text-white' }}">
                    <i class="fas fa-layer-group w-6 text-center"></i>
                    <span class="sidebar-text ml-3 font-medium">Plans</span>
                </a>
                
                <a href="{{ route('super-admin.subscriptions.index') }}" class="nav-link flex items-center px-4 py-3 rounded-lg transition-all duration-200 {{ request()->routeIs('super-admin.subscriptions.*') ? 'bg-[#00008B] text-white shadow-md' : 'text-gray-300 hover:bg-gray-800 hover:text-white' }}">
                    <i class="fas fa-credit-card w-6 text-center"></i>
                    <span class="sidebar-text ml-3 font-medium">Subscriptions</span>
                </a>
            </div>
            
            <div class="px-3 mt-6 mb-2">
                <p class="px-4 text-xs font-semibold text-gray-400 uppercase tracking-wider">AI System</p>
            </div>
            
            <div class="space-y-1 px-3">
                <a href="{{ route('super-admin.ai-settings.index') }}" class="nav-link flex items-center px-4 py-3 rounded-lg transition-all duration-200 {{ request()->routeIs('super-admin.ai-settings.index') ? 'bg-[#00008B] text-white shadow-md' : 'text-gray-300 hover:bg-gray-800 hover:text-white' }}">
                    <i class="fas fa-robot w-6 text-center"></i>
                    <span class="sidebar-text ml-3 font-medium">AI Settings</span>
                </a>
                <a href="{{ route('super-admin.ai-settings.analytics') }}" class="nav-link flex items-center px-4 py-3 rounded-lg transition-all duration-200 {{ request()->routeIs('super-admin.ai-settings.analytics') ? 'bg-[#00008B] text-white shadow-md' : 'text-gray-300 hover:bg-gray-800 hover:text-white' }}">
                    <i class="fas fa-chart-line w-6 text-center"></i>
                    <span class="sidebar-text ml-3 font-medium">AI Analytics</span>
                </a>
                <a href="{{ route('super-admin.ai-settings.knowledge') }}" class="nav-link flex items-center px-4 py-3 rounded-lg transition-all duration-200 {{ request()->routeIs('super-admin.ai-settings.knowledge*') ? 'bg-[#00008B] text-white shadow-md' : 'text-gray-300 hover:bg-gray-800 hover:text-white' }}">
                    <i class="fas fa-brain w-6 text-center"></i>
                    <span class="sidebar-text ml-3 font-medium">AI Knowledge</span>
                </a>
            </div>
            
            <div class="px-3 mt-6 mb-2">
                <p class="px-4 text-xs font-semibold text-gray-400 uppercase tracking-wider">System</p>
            </div>
            
            <div class="space-y-1 px-3">
                <a href="{{ route('super-admin.activity-logs') }}" class="nav-link flex items-center px-4 py-3 rounded-lg transition-all duration-200 {{ request()->routeIs('super-admin.activity-logs') ? 'bg-[#00008B] text-white shadow-md' : 'text-gray-300 hover:bg-gray-800 hover:text-white' }}">
                    <i class="fas fa-history w-6 text-center"></i>
                    <span class="sidebar-text ml-3 font-medium">Activity Logs</span>
                </a>
                
                <a href="{{ route('super-admin.system-health') }}" class="nav-link flex items-center px-4 py-3 rounded-lg transition-all duration-200 {{ request()->routeIs('super-admin.system-health') ? 'bg-[#00008B] text-white shadow-md' : 'text-gray-300 hover:bg-gray-800 hover:text-white' }}">
                    <i class="fas fa-heartbeat w-6 text-center"></i>
                    <span class="sidebar-text ml-3 font-medium">System Health</span>
                </a>
                
                <a href="{{ route('super-admin.broadcast') }}" class="nav-link flex items-center px-4 py-3 rounded-lg transition-all duration-200 {{ request()->routeIs('super-admin.broadcast*') ? 'bg-[#00008B] text-white shadow-md' : 'text-gray-300 hover:bg-gray-800 hover:text-white' }}">
                    <i class="fas fa-bullhorn w-6 text-center"></i>
                    <span class="sidebar-text ml-3 font-medium">Broadcast</span>
                </a>
                
                <a href="{{ route('super-admin.messages.index') }}" class="nav-link flex items-center px-4 py-3 rounded-lg transition-all duration-200 {{ request()->routeIs('super-admin.messages*') ? 'bg-[#00008B] text-white shadow-md' : 'text-gray-300 hover:bg-gray-800 hover:text-white' }}">
                    <i class="fas fa-comment-dots w-6 text-center"></i>
                    <span class="sidebar-text ml-3 font-medium">Messages</span>
                </a>
                
                <a href="{{ route('super-admin.form-fields.index') }}" class="nav-link flex items-center px-4 py-3 rounded-lg transition-all duration-200 {{ request()->routeIs('super-admin.form-fields*') ? 'bg-[#00008B] text-white shadow-md' : 'text-gray-300 hover:bg-gray-800 hover:text-white' }}">
                    <i class="fas fa-th-list w-6 text-center"></i>
                    <span class="sidebar-text ml-3 font-medium">Form Fields</span>
                </a>
                
                <a href="{{ route('super-admin.faqs.index') }}" class="nav-link flex items-center px-4 py-3 rounded-lg transition-all duration-200 {{ request()->routeIs('super-admin.faqs*') ? 'bg-[#00008B] text-white shadow-md' : 'text-gray-300 hover:bg-gray-800 hover:text-white' }}">
                    <i class="fas fa-question-circle w-6 text-center"></i>
                    <span class="sidebar-text ml-3 font-medium">FAQs</span>
                </a>
                
                <a href="{{ route('home') }}" target="_blank" class="nav-link flex items-center px-4 py-3 rounded-lg transition-all duration-200 text-gray-300 hover:bg-gray-800 hover:text-white">
                    <i class="fas fa-external-link-alt w-6 text-center"></i>
                    <span class="sidebar-text ml-3 font-medium">View Landing Page</span>
                </a>
                  
                <form action="{{ route('super-admin.settings.clear-cache') }}" method="POST" class="nav-link">
                    @csrf
                    <button type="submit" class="w-full flex items-center px-4 py-3 rounded-lg transition-all duration-200 text-gray-300 hover:bg-gray-800 hover:text-white">
                        <i class="fas fa-sync w-6 text-center"></i>
                        <span class="sidebar-text ml-3 font-medium">Clear Cache</span>
                    </button>
                </form>
                 
                <a href="{{ route('super-admin.backups.index') }}" class="nav-link flex items-center px-4 py-3 rounded-lg transition-all duration-200 {{ request()->routeIs('super-admin.backups.*') ? 'bg-[#00008B] text-white shadow-md' : 'text-gray-300 hover:bg-gray-800 hover:text-white' }}">
                    <i class="fas fa-database w-6 text-center"></i>
                    <span class="sidebar-text ml-3 font-medium">Backups</span>
                </a>
            </div>
            
            <div class="px-3 mt-6 mb-2">
                <p class="px-4 text-xs font-semibold text-gray-400 uppercase tracking-wider">Settings</p>
            </div>
            
            <div class="space-y-1 px-3">
                <a href="{{ route('super-admin.roles.index') }}" class="nav-link flex items-center px-4 py-3 rounded-lg transition-all duration-200 {{ request()->routeIs('super-admin.roles.*') ? 'bg-[#00008B] text-white shadow-md' : 'text-gray-300 hover:bg-gray-800 hover:text-white' }}">
                    <i class="fas fa-user-shield w-6 text-center"></i>
                    <span class="sidebar-text ml-3 font-medium">Roles & Permissions</span>
                </a>
                
                <a href="{{ route('super-admin.settings') }}" class="nav-link flex items-center px-4 py-3 rounded-lg transition-all duration-200 {{ request()->routeIs('super-admin.settings') ? 'bg-[#00008B] text-white shadow-md' : 'text-gray-300 hover:bg-gray-800 hover:text-white' }}">
                    <i class="fas fa-cog w-6 text-center"></i>
                    <span class="sidebar-text ml-3 font-medium">Global Settings</span>
                </a>
            </div>
        </nav>
        
        {{-- Sidebar Footer --}}
        <div class="p-4 border-t border-gray-700 bg-gray-800">
            <div class="flex items-center justify-between mb-3">
                <div class="flex items-center">
                    <div class="w-10 h-10 rounded-full overflow-hidden flex items-center justify-center">
                        <x-user-avatar :user="auth()->user()" :size="40" class="" />
                    </div>
                    <div class="sidebar-expanded ml-3">
                        <p class="text-sm font-medium text-white">{{ auth()->user()->fullName() }}</p>
                        <p class="text-xs text-gray-400">
                            <i class="fas fa-crown mr-1"></i> Super Admin
                        </p>
                    </div>
                </div>
            </div>
            <form action="{{ route('logout') }}" method="POST">
                @csrf
                <button type="submit" class="w-full py-2 bg-red-600 rounded-lg text-xs font-medium text-white hover:bg-red-700 transition-colors">
                    <i class="fas fa-sign-out-alt mr-1"></i> Logout
                </button>
            </form>
        </div>
    </aside>

    {{-- Mobile Sidebar Overlay --}}
    <div id="sidebarOverlay" class="fixed inset-0 bg-black bg-opacity-50 z-20 hidden lg:hidden"></div>
    
    {{-- Main Content --}}
    <main class="flex-1 flex flex-col min-h-screen ml-64">
        {{-- Top Header --}}
        <header class="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-10">
            <div class="h-16 px-4 sm:px-6 flex items-center justify-between">
                {{-- Left: Menu Toggle & Title --}}
                <div class="flex items-center">
                    <button id="openSidebar" class="lg:hidden mr-4 p-2 text-gray-500 hover:text-blue-600 hover:bg-gray-100 rounded-lg transition-colors">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path>
                        </svg>
                    </button>
                    <button id="collapseSidebar" class="hidden lg:block p-2 text-gray-500 hover:text-blue-600 hover:bg-gray-100 rounded-lg transition-colors">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 19l-7-7 7-7m8 14l-7-7 7-7"></path>
                        </svg>
                    </button>
                    <div>
                        <h2 class="text-lg sm:text-xl font-semibold text-gray-900">@yield('header', 'Dashboard')</h2>
                    </div>
                </div>
                
                {{-- Right: Actions --}}
                <div class="flex items-center gap-2 sm:gap-3">
                    {{-- Quick Search - Hidden on mobile --}}
                    <div class="hidden lg:block relative">
                        <input type="text" placeholder="Search schools..." class="w-40 xl:w-64 pl-10 pr-4 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all">
                        <svg class="w-5 h-5 text-gray-400 absolute left-3 top-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                        </svg>
                    </div>
                    
                    {{-- Notifications --}}
                    <x-notification-dropdown :url="route('super-admin.broadcast')" />
                    
                    {{-- Messages - Hidden on mobile --}}
                    <div class="hidden sm:block">
                        <x-chat-dropdown />
                    </div>
                    
                    {{-- Language Switcher - Hidden on mobile --}}
                    <div class="hidden lg:flex items-center bg-gray-100 rounded-lg p-1">
                        <a href="{{ route('lang', 'en') }}" class="px-2 sm:px-3 py-1 rounded-md text-xs sm:text-sm font-medium transition-colors {{ app()->getLocale() == 'en' ? 'bg-[#00008B] text-white shadow-sm' : 'text-gray-600 hover:text-blue-600' }}">
                            EN
                        </a>
                        <a href="{{ route('lang', 'sw') }}" class="px-2 sm:px-3 py-1 rounded-md text-xs sm:text-sm font-medium transition-colors {{ app()->getLocale() == 'sw' ? 'bg-[#00008B] text-white shadow-sm' : 'text-gray-600 hover:text-blue-600' }}">
                            SW
                        </a>
                    </div>
                    
                    {{-- User Profile Dropdown --}}
                    <div class="relative" x-data="{ open: false }">
                        <button @click="open = !open" class="flex items-center space-x-1 sm:space-x-2 p-1.5 sm:p-2 hover:bg-gray-100 rounded-lg transition-colors">
                            <div class="w-8 h-8 rounded-full overflow-hidden flex items-center justify-center flex-shrink-0">
                                <x-user-avatar :user="auth()->user()" :size="32" class="" />
                            </div>
                            <span class="hidden md:block text-sm font-medium text-gray-700">{{ auth()->user()->first_name }}</span>
                            <i class="fas fa-chevron-down text-xs text-gray-400 hidden md:block"></i>
                        </button>
                        
                        <div x-show="open" x-cloak @click.away="open = false" x-transition:enter="transition ease-out duration-100" x-transition:enter-start="transform opacity-0 scale-95" x-transition:enter-end="transform opacity-100 scale-100" x-transition:leave="transition ease-in duration-75" x-transition:leave-start="transform opacity-100 scale-100" x-transition:leave-end="transform opacity-0 scale-95" class="absolute right-0 mt-2 w-56 bg-white rounded-xl shadow-xl border border-gray-200 py-2">
                            <div class="px-4 py-2 border-b border-gray-100">
                                <p class="text-sm font-medium text-gray-900">{{ auth()->user()->fullName() }}</p>
                                <p class="text-xs text-gray-500">{{ auth()->user()->email }}</p>
                            </div>
                            <a href="{{ route('super-admin.profile.edit') }}" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 transition-colors">
                                <i class="fas fa-user mr-2"></i> Profile Management
                            </a>
                            <a href="{{ route('super-admin.settings') }}" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 transition-colors">
                                <i class="fas fa-cog mr-2"></i> Settings
                            </a>
                            <div class="border-t border-gray-100 mt-2 pt-2">
                                <form action="{{ route('logout') }}" method="POST">
                                    @csrf
                                    <button type="submit" class="w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50 transition-colors">
                                        <i class="fas fa-sign-out-alt mr-2"></i> Logout
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        
        {{-- Flash Messages --}}
        <div class="px-4 sm:px-6 pt-4">
            @if(session('success'))
            <div class="mb-4 bg-green-50 border border-green-200 text-green-800 px-4 py-3 rounded-lg flex items-center animate-slide-in">
                <i class="fas fa-check-circle mr-3 text-green-600"></i>
                <span class="text-sm">{{ session('success') }}</span>
                <button type="button" class="ml-auto text-green-600 hover:text-green-800" onclick="this.parentElement.remove()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            @endif
            
            @if(session('error'))
            <div class="mb-4 bg-red-50 border border-red-200 text-red-800 px-4 py-3 rounded-lg flex items-center animate-slide-in">
                <i class="fas fa-exclamation-circle mr-3 text-red-600"></i>
                <span class="text-sm">{{ session('error') }}</span>
                <button type="button" class="ml-auto text-red-600 hover:text-red-800" onclick="this.parentElement.remove()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            @endif
            
            @if(session('info'))
            <div class="mb-4 bg-blue-50 border border-blue-200 text-blue-800 px-4 py-3 rounded-lg flex items-center animate-slide-in">
                <i class="fas fa-info-circle mr-3 text-blue-600"></i>
                <span class="text-sm">{{ session('info') }}</span>
                <button type="button" class="ml-auto text-blue-600 hover:text-blue-800" onclick="this.parentElement.remove()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            @endif
        </div>
        
        {{-- Page Content --}}
        <div class="flex-1 p-4 sm:p-6">
            @yield('content')
        </div>
        
        {{-- Footer --}}
        <footer class="bg-white border-t border-gray-200 px-6 py-4 mt-auto">
            <div class="flex flex-col sm:flex-row items-center justify-between text-xs text-gray-500">
                <p>© {{ date('Y') }} {{ system_setting('system_name', 'Admission Portal') }}. All rights reserved.</p>
                @if(system_setting('show_footer_branding', true))
                    <span class="text-xs text-gray-400 mt-2 sm:mt-0">
                        Powered by <a href="https://duncowebsolutions.com" target="_blank" class="hover:text-blue-600 transition-colors">Duncowebsolutions</a>
                    </span>
                @endif
            </div>
        </footer>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
    <script>
        const sidebar = document.getElementById('sidebar');
        const sidebarOverlay = document.getElementById('sidebarOverlay');
        const openSidebarBtn = document.getElementById('openSidebar');
        const closeSidebarBtn = document.getElementById('closeSidebar');
        const collapseSidebarBtn = document.getElementById('collapseSidebar');
        
        let sidebarCollapsed = false;
        
        function openSidebar() {
            sidebar.classList.remove('-translate-x-full');
            sidebarOverlay.classList.remove('hidden');
        }
        
        function closeSidebar() {
            sidebar.classList.add('-translate-x-full');
            sidebarOverlay.classList.add('hidden');
        }
        
        function toggleSidebarCollapse() {
            sidebarCollapsed = !sidebarCollapsed;
            const mainContent = document.querySelector('main');
            if (sidebarCollapsed) {
                sidebar.classList.add('w-20');
                sidebar.classList.remove('w-64');
                mainContent.classList.remove('ml-64');
                mainContent.classList.add('ml-20');
                document.querySelectorAll('.sidebar-text').forEach(el => el.classList.add('hidden'));
                document.querySelectorAll('.sidebar-expanded').forEach(el => el.classList.add('hidden'));
            } else {
                sidebar.classList.remove('w-20');
                sidebar.classList.add('w-64');
                mainContent.classList.remove('ml-20');
                mainContent.classList.add('ml-64');
                document.querySelectorAll('.sidebar-text').forEach(el => el.classList.remove('hidden'));
                document.querySelectorAll('.sidebar-expanded').forEach(el => el.classList.remove('hidden'));
            }
        }
        
        openSidebarBtn?.addEventListener('click', openSidebar);
        closeSidebarBtn?.addEventListener('click', closeSidebar);
        sidebarOverlay?.addEventListener('click', closeSidebar);
        collapseSidebarBtn?.addEventListener('click', toggleSidebarCollapse);
        
        // Add blue active state styling to nav links
        const navLinks = document.querySelectorAll('.nav-link');
        navLinks.forEach(link => {
            if (link.classList.contains('bg-\\[\\#00008B\\]')) {
                link.classList.add('bg-[#00008B]', 'text-white', 'shadow-md');
                link.classList.remove('text-gray-300', 'hover:bg-gray-800', 'hover:text-white');
            }
        });
        
        @if(session('success') || session('error') || session('info'))
        setTimeout(() => {
            document.querySelectorAll('.animate-slide-in').forEach(el => {
                el.style.opacity = '0';
                el.style.transform = 'translateX(100%)';
                setTimeout(() => el.remove(), 300);
            });
        }, 5000);
        @endif
    </script>
    <script>
        window.onerror = function(msg, url, lineNo, columnNo, error) {
            if (msg.includes('giveFreely') || msg.includes('payload')) {
                return true;
            }
            console.error('Global error:', msg, 'at', url, ':', lineNo, ':', columnNo);
            return false;
        };
        window.addEventListener('unhandledrejection', function(event) {
            if (event.reason && event.reason.message && (event.reason.message.includes('giveFreely') || event.reason.message.includes('payload'))) {
                event.preventDefault();
            }
        });
    </script>
    <x-ai-chat-widget mode="system" />
    <style>
        @keyframes slide-in {
            from { opacity: 0; transform: translateX(100%); }
            to { opacity: 1; transform: translateX(0); }
        }
        .animate-slide-in { animation: slide-in 0.3s ease-out; }
    </style>
    @stack('scripts')
</body>
</html>
