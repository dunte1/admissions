@extends('layouts.super-admin')

@section('header', $school->name . ' Settings')
@section('breadcrumb', 'Configure school-specific settings')

@section('content')
<div class="space-y-6">
    <div class="flex items-center justify-between">
        <div>
            <h1 class="text-2xl font-bold text-gray-900">{{ $school->name }} Settings</h1>
            <p class="text-sm text-gray-500">Configure school-specific settings</p>
        </div>
        <a href="{{ route('super-admin.schools.show', $school) }}" class="inline-flex items-center px-4 py-2 text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors">
            <i class="fas fa-arrow-left mr-2"></i>
            Back
        </a>
    </div>

    @if(session('success'))
        <div class="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg">
            {{ session('success') }}
        </div>
    @endif

    <form action="{{ route('super-admin.schools.settings.update', $school) }}" method="POST">
        @csrf

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div class="bg-white rounded-xl shadow-sm p-6">
                <h3 class="text-lg font-semibold text-gray-900 mb-4">Application Settings</h3>
                
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Application Fee</label>
                        <div class="flex">
                            <span class="inline-flex items-center px-3 rounded-l-md border border-r-0 border-gray-300 bg-gray-50 text-gray-500 text-sm">
                                {{ $school->currency_symbol ?? 'KSh' }}
                            </span>
                            <input type="number" name="application_fee" value="{{ old('application_fee', $settings['application_fee'] ?? 2000) }}" step="0.01"
                                class="flex-1 px-3 py-2 border border-gray-300 rounded-r-lg focus:ring-2 focus:ring-purple-500">
                        </div>
                    </div>

                    <div class="flex items-center">
                        <input type="checkbox" name="allow_multiple_applications" id="allow_multiple" value="1"
                            {{ old('allow_multiple_applications', $settings['allow_multiple_applications'] ?? false) ? 'checked' : '' }}
                            class="w-4 h-4 text-purple-600 border-gray-300 rounded focus:ring-purple-500">
                        <label for="allow_multiple" class="ml-2 block text-sm text-gray-700">
                            Allow multiple applications per student
                        </label>
                    </div>

                    <div class="flex items-center">
                        <input type="checkbox" name="require_payment_before_submission" id="require_payment" value="1"
                            {{ old('require_payment_before_submission', $settings['require_payment_before_submission'] ?? true) ? 'checked' : '' }}
                            class="w-4 h-4 text-purple-600 border-gray-300 rounded focus:ring-purple-500">
                        <label for="require_payment" class="ml-2 block text-sm text-gray-700">
                            Require payment before submission
                        </label>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-xl shadow-sm p-6">
                <h3 class="text-lg font-semibold text-gray-900 mb-4">Payment Settings</h3>
                
                <div class="space-y-4">
                    <div class="flex items-center">
                        <input type="checkbox" name="enable_online_payment" id="enable_payment" value="1"
                            {{ old('enable_online_payment', $settings['enable_online_payment'] ?? true) ? 'checked' : '' }}
                            class="w-4 h-4 text-purple-600 border-gray-300 rounded focus:ring-purple-500">
                        <label for="enable_payment" class="ml-2 block text-sm text-gray-700">
                            Enable online payments
                        </label>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">M-PESA Shortcode</label>
                        <input type="text" name="mpesa_shortcode" value="{{ old('mpesa_shortcode', $settings['mpesa_shortcode'] ?? '') }}"
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500">
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">M-PESA Passkey</label>
                        <input type="password" name="mpesa_passkey" value="{{ old('mpesa_passkey', $settings['mpesa_passkey'] ?? '') }}"
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500">
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-xl shadow-sm p-6">
                <h3 class="text-lg font-semibold text-gray-900 mb-4">Email Settings</h3>
                
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">From Address</label>
                        <input type="email" name="email_from_address" value="{{ old('email_from_address', $settings['email_from_address'] ?? $school->email) }}"
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500">
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">From Name</label>
                        <input type="text" name="email_from_name" value="{{ old('email_from_name', $settings['email_from_name'] ?? $school->name) }}"
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500">
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-xl shadow-sm p-6">
                <h3 class="text-lg font-semibold text-gray-900 mb-4">SMS Settings</h3>
                
                <div class="space-y-4">
                    <div class="flex items-center">
                        <input type="checkbox" name="sms_enabled" id="sms_enabled" value="1"
                            {{ old('sms_enabled', $settings['sms_enabled'] ?? false) ? 'checked' : '' }}
                            class="w-4 h-4 text-purple-600 border-gray-300 rounded focus:ring-purple-500">
                        <label for="sms_enabled" class="ml-2 block text-sm text-gray-700">
                            Enable SMS notifications
                        </label>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">SMS API Key</label>
                        <input type="password" name="sms_api_key" value="{{ old('sms_api_key', $settings['sms_api_key'] ?? '') }}"
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500">
                    </div>
                </div>
            </div>
        </div>

        <div class="mt-6 flex items-center justify-end">
            <button type="submit" class="px-6 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors">
                <i class="fas fa-save mr-2"></i>
                Save Settings
            </button>
        </div>
    </form>
</div>
@endsection
