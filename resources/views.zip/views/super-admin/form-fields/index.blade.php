@extends('layouts.super-admin')

@section('header', 'Form Fields Management')
@section('breadcrumb', 'Customize admission form fields per school')

@section('content')
<div class="space-y-6">
    <div class="flex items-center justify-between gap-4">
        <form method="GET" action="{{ route('super-admin.form-fields.index') }}" class="flex items-center space-x-2">
            <select name="school_id" onchange="this.form.submit()" class="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500">
                <option value="">Select School...</option>
                @foreach($schools as $school)
                    <option value="{{ $school->id }}" {{ $schoolId == $school->id ? 'selected' : '' }}>
                        {{ $school->name }}
                    </option>
                @endforeach
            </select>
        </form>
        @if($schoolId)
            <a href="{{ route('super-admin.form-fields.create-section', ['school_id' => $schoolId]) }}" 
               class="inline-flex items-center px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors whitespace-nowrap">
                <i class="fas fa-plus mr-2"></i>
                Add Section
            </a>
        @endif
    </div>

    @if(session('success'))
        <div class="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg">
            {{ session('success') }}
        </div>
    @endif

    @if(session('error'))
        <div class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
            {{ session('error') }}
        </div>
    @endif

    @if(!$schoolId)
        <div class="bg-blue-50 border border-blue-200 text-blue-700 px-4 py-3 rounded-lg">
            <i class="fas fa-info-circle mr-2"></i>
            Select a school to manage its form fields, or manage default fields.
        </div>
    @endif

    <div class="space-y-6">
        @forelse($sections as $section)
            <div class="bg-white rounded-xl shadow-sm overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200 flex items-center justify-between bg-gray-50">
                    <div class="flex items-center">
                        <div class="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center mr-3">
                            <i class="fas {{ $section->icon ?? 'fa-circle' }} text-purple-600"></i>
                        </div>
                        <div>
                            <h3 class="font-semibold text-gray-900">{{ $section->name }}</h3>
                            <p class="text-xs text-gray-500">{{ $section->fields->count() }} fields | {{ $section->is_active ? 'Active' : 'Inactive' }}</p>
                        </div>
                    </div>
                    <div class="flex items-center space-x-2">
                        @if($section->is_active)
                            <span class="px-2 py-1 bg-green-100 text-green-700 rounded text-xs font-medium">Active</span>
                        @else
                            <span class="px-2 py-1 bg-gray-100 text-gray-700 rounded text-xs font-medium">Inactive</span>
                        @endif
                        
                        @if($section->school_id)
                            <form action="{{ route('super-admin.form-fields.toggle-section', $section) }}" method="POST" class="inline">
                                @csrf
                                <input type="hidden" name="school_id" value="{{ $schoolId }}">
                                <button type="submit" class="p-2 text-gray-400 hover:text-purple-600" title="{{ $section->is_active ? 'Disable' : 'Enable' }}">
                                    <i class="fas {{ $section->is_active ? 'fa-toggle-on' : 'fa-toggle-off' }}"></i>
                                </button>
                            </form>
                        @endif
                        
                        <a href="{{ route('super-admin.form-fields.create-field', [$section, 'school_id' => $schoolId]) }}" 
                           class="p-2 text-gray-400 hover:text-green-600" title="Add Field">
                            <i class="fas fa-plus"></i>
                        </a>
                        <a href="{{ route('super-admin.form-fields.edit-section', [$section, 'school_id' => $schoolId]) }}" 
                           class="p-2 text-gray-400 hover:text-blue-600" title="Edit Section">
                            <i class="fas fa-edit"></i>
                        </a>
                        @if($section->school_id)
                            <form action="{{ route('super-admin.form-fields.destroy-section', $section) }}" method="POST" class="inline"
                                  onsubmit="return confirm('Are you sure?')">
                                @csrf
                                @method('DELETE')
                                <input type="hidden" name="school_id" value="{{ $schoolId }}">
                                <button type="submit" class="p-2 text-gray-400 hover:text-red-600" title="Delete Section">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                        @endif
                    </div>
                </div>
                
                <div class="p-4">
                    @if($section->fields->count() > 0)
                        <table class="w-full">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Order</th>
                                    <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Field</th>
                                    <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Type</th>
                                    <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Required</th>
                                    <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                                    <th class="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-100">
                                @foreach($section->fields->sortBy('order') as $field)
                                    <tr class="{{ !$field->is_active ? 'bg-gray-50 text-gray-400' : '' }}">
                                        <td class="px-4 py-2 text-sm">{{ $field->order }}</td>
                                        <td class="px-4 py-2">
                                            <div class="font-medium text-gray-900">{{ $field->label }}</div>
                                            <div class="text-xs text-gray-500">Key: {{ $field->key }}</div>
                                        </td>
                                        <td class="px-4 py-2 text-sm">
                                            <span class="px-2 py-1 bg-gray-100 rounded text-xs">
                                                <i class="fas fa-{{ $field->type == 'text' ? 'fa-font' : ($field->type == 'select' ? 'fa-list' : ($field->type == 'file' ? 'fa-file' : 'fa-edit')) }} mr-1"></i>
                                                {{ $field->type }}
                                            </span>
                                        </td>
                                        <td class="px-4 py-2 text-sm">
                                            @if($field->is_required)
                                                <span class="text-red-500"><i class="fas fa-check-circle"></i> Yes</span>
                                            @else
                                                <span class="text-gray-400">No</span>
                                            @endif
                                        </td>
                                        <td class="px-4 py-2">
                                            @if($field->is_active)
                                                <span class="px-2 py-1 bg-green-100 text-green-700 rounded text-xs">Active</span>
                                            @else
                                                <span class="px-2 py-1 bg-gray-100 text-gray-600 rounded text-xs">Inactive</span>
                                            @endif
                                        </td>
                                        <td class="px-4 py-2 text-right">
                                            <div class="flex items-center justify-end space-x-1">
                                                <form action="{{ route('super-admin.form-fields.toggle-field', $field) }}" method="POST" class="inline">
                                                    @csrf
                                                    <input type="hidden" name="school_id" value="{{ $schoolId }}">
                                                    <button type="submit" class="p-1 text-gray-400 hover:text-purple-600" title="Toggle">
                                                        <i class="fas {{ $field->is_active ? 'fa-toggle-on' : 'fa-toggle-off' }}"></i>
                                                    </button>
                                                </form>
                                                <a href="{{ route('super-admin.form-fields.edit-field', [$field, 'school_id' => $schoolId]) }}" 
                                                   class="p-1 text-gray-400 hover:text-blue-600" title="Edit">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                <form action="{{ route('super-admin.form-fields.destroy-field', $field) }}" method="POST" class="inline"
                                                      onsubmit="return confirm('Are you sure?')">
                                                    @csrf
                                                    @method('DELETE')
                                                    <input type="hidden" name="school_id" value="{{ $schoolId }}">
                                                    <button type="submit" class="p-1 text-gray-400 hover:text-red-600" title="Delete">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    @else
                        <p class="text-center text-gray-500 py-4">No fields in this section. <a href="{{ route('super-admin.form-fields.create-field', [$section, 'school_id' => $schoolId]) }}" class="text-purple-600 hover:underline">Add a field</a></p>
                    @endif
                </div>
            </div>
        @empty
            <div class="bg-white rounded-xl shadow-sm p-12 text-center">
                <i class="fas fa-forms text-4xl text-gray-300 mb-4"></i>
                <h3 class="text-lg font-medium text-gray-900">No form sections found</h3>
                <p class="text-gray-500 mt-1">Get started by creating a section.</p>
                @if($schoolId)
                    <a href="{{ route('super-admin.form-fields.create-section', ['school_id' => $schoolId]) }}" 
                       class="inline-flex items-center px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 mt-4">
                        <i class="fas fa-plus mr-2"></i>
                        Create Section
                    </a>
                @endif
            </div>
        @endforelse
    </div>
</div>
@endsection
