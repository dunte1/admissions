<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $letter->letter_number }}</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Times New Roman', serif; font-size: 12pt; line-height: 1.6; padding: 40px; }
        .header { text-align: center; margin-bottom: 40px; border-bottom: 2px solid #000; padding-bottom: 20px; }
        .header h1 { font-size: 18pt; margin-bottom: 5px; }
        .header p { font-size: 10pt; color: #666; }
        .content { margin-bottom: 30px; }
        .content p { margin-bottom: 15px; text-align: justify; }
        .content .recipient { margin: 20px 0; }
        .content .subject { font-weight: bold; margin-bottom: 15px; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        table th, table td { border: 1px solid #ddd; padding: 10px; text-align: left; }
        table th { background: #f5f5f5; }
        .conditions { background: #f9f9f9; padding: 15px; margin: 20px 0; border-left: 4px solid #000; }
        .signature { margin-top: 50px; }
        .signature .name { font-weight: bold; border-bottom: 1px solid #000; padding-bottom: 5px; width: 200px; }
        .signature .title { color: #666; }
        .footer { margin-top: 50px; font-size: 9pt; color: #666; text-align: center; border-top: 1px solid #ddd; padding-top: 20px; }
        .admission { color: #2e7d32; }
        .rejection { color: #c62828; }
        .provisional { color: #f57c00; }
    </style>
</head>
<body>
    <div class="header">
        <h1>{{ $institution }}</h1>
        <p>{{ $address }}</p>
        <p>Tel: {{ $phone }} | Email: {{ $email }}</p>
    </div>

    <div class="content">
        <p>{{ $letter->issue_date->format('F d, Y') }}</p>
        
        <div class="recipient">
            <p><strong>To:</strong></p>
            <p>{{ $letter->application->student->fullName() }}</p>
            <p>Email: {{ $letter->application->user->email }}</p>
        </div>

        <p class="subject">{{ strtoupper($letter->type) }} LETTER</p>

        <p>Dear {{ $letter->application->student->first_name }},</p>

        @if($letter->type === 'admission')
            <p class="admission">We are pleased to inform you that after careful consideration of your application, the Admissions Committee has offered you a place in our <strong>{{ $letter->application->program->name ?? 'Program' }}</strong>.</p>

            <p>This offer is subject to the following conditions:</p>

            <div class="conditions">
                <strong>Offer Details:</strong>
                <table>
                    <tr>
                        <th width="30%">Program</th>
                        <td>{{ $letter->application->program->name ?? 'N/A' }}</td>
                    </tr>
                    <tr>
                        <th>Application Number</th>
                        <td>{{ $letter->application->application_number }}</td>
                    </tr>
                    <tr>
                        <th>Letter Reference</th>
                        <td>{{ $letter->letter_number }}</td>
                    </tr>
                </table>
            </div>

            @if($letter->additional_conditions)
            <div class="conditions">
                <strong>Additional Conditions:</strong>
                <p>{{ $letter->additional_conditions }}</p>
            </div>
            @endif

            @if($letter->response_deadline)
            <p><strong>Response Deadline:</strong> Please confirm your acceptance by <u>{{ $letter->response_deadline->format('F d, Y') }}</u>. Failure to respond by this date may result in the offer being withdrawn.</p>
            @endif

            <p>To accept this offer, please:</p>
            <ol>
                <li>Log in to the student portal at our website</li>
                <li>Navigate to "My Applications" and view your offer</li>
                <li>Click "Accept Offer" and follow the instructions</li>
            </ol>

            <p>We look forward to welcoming you to our institution.</p>

        @elseif($letter->type === 'rejection')
            <p class="rejection">After careful review of your application, we regret to inform you that we are unable to offer you admission at this time.</p>

            <p>This decision was based on a comprehensive review of all applications received, and unfortunately, we had to make difficult choices due to the high volume of qualified candidates.</p>

            @if($letter->additional_conditions)
            <p>{{ $letter->additional_conditions }}</p>
            @endif

            <p>We encourage you to apply again in the future, and we wish you the best in your academic pursuits.</p>

        @elseif($letter->type === 'provisional')
            <p class="provisional">Your application has been provisionally accepted, subject to the fulfillment of the conditions listed below.</p>

            <div class="conditions">
                <strong>Conditions to be Fulfilled:</strong>
                <p>{!! nl2br($letter->additional_conditions ?? 'Please check the requirements in your student portal.') !!}</p>
            </div>

            @if($letter->response_deadline)
            <p><strong>Deadline:</strong> All conditions must be fulfilled by <u>{{ $letter->response_deadline->format('F d, Y') }}</u>.</p>
            @endif
        @endif

        @if($letter->remarks)
        <p><strong>Additional Remarks:</strong> {{ $letter->remarks }}</p>
        @endif
    </div>

    <div class="signature">
        <p>Sincerely,</p>
        <br><br>
        <div class="name">Admissions Office</div>
        <p class="title">On behalf of the Admissions Committee</p>
    </div>

    <div class="footer">
        <p>This is an official document generated by {{ $institution }}.</p>
        <p>Letter Reference: {{ $letter->letter_number }} | Generated: {{ now()->format('F d, Y H:i:s') }}</p>
    </div>
</body>
</html>