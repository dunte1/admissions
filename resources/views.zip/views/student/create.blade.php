@extends('layouts.student')

@section('title', 'Select Program')

@section('content')
<div class="max-w-5xl mx-auto">
    <div class="mb-8">
        <h1 class="text-3xl font-bold text-gray-900">{{ __('labels.new_application') }}</h1>
        <p class="text-gray-600 mt-2">Select your preferred programs and get started</p>
    </div>

    <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
        <form action="{{ route('student.application.store') }}" method="POST" id="programForm">
            @csrf
            
            <div class="mb-8">
                <h2 class="text-lg font-semibold text-gray-900 mb-2 flex items-center">
                    <span class="w-8 h-8 bg-[#00008B] text-white rounded-full flex items-center justify-center text-sm font-bold mr-3">1</span>
                    Choose Your Programs (Select up to 3)
                </h2>
                <p class="text-sm text-gray-500 ml-11 mb-6">Select your first, second, and third choice programs. Your first choice will be given priority during review.</p>
            </div>

            {{-- Program Choices --}}
            <div class="space-y-6 mb-8">
                {{-- First Choice --}}
                <div class="p-6 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl border-2 border-blue-200">
                    <div class="flex items-center mb-4">
                        <span class="flex items-center justify-center w-8 h-8 bg-[#00008B] text-white rounded-full text-sm font-bold mr-3">1st</span>
                        <h3 class="font-semibold text-gray-900">First Choice (Priority)</h3>
                        <span class="ml-2 text-xs bg-[#00008B] text-white px-2 py-0.5 rounded-full">Required</span>
                    </div>
                    <select name="program_id_1" id="program1" required 
                        class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#00008B] focus:border-[#00008B]" 
                        onchange="updateProgramDetails(1)">
                        <option value="">-- Select First Choice Program --</option>
                        @foreach($programs as $program)
                            <option value="{{ $program->id }}" 
                                data-level="{{ $program->level }}"
                                data-duration="{{ $program->duration_years }}"
                                data-requirements="{{ $program->requirements ?? 'None specified' }}"
                                data-tution="{{ $program->tuition_per_year }}">
                                {{ $program->name }} ({{ $program->code }})
                            </option>
                        @endforeach
                    </select>
                    <div id="program1Details" class="mt-4 hidden">
                        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                            <div class="bg-white p-3 rounded-lg">
                                <p class="text-gray-500">Level</p>
                                <p class="font-semibold text-gray-900" id="program1Level">-</p>
                            </div>
                            <div class="bg-white p-3 rounded-lg">
                                <p class="text-gray-500">Duration</p>
                                <p class="font-semibold text-gray-900" id="program1Duration">-</p>
                            </div>
                            <div class="bg-white p-3 rounded-lg">
                                <p class="text-gray-500">Tuition/Year</p>
                                <p class="font-semibold text-gray-900" id="program1Tuition">-</p>
                            </div>
                            <div class="bg-white p-3 rounded-lg">
                                <p class="text-gray-500">Requirements</p>
                                <p class="font-semibold text-gray-900" id="program1Requirements">-</p>
                            </div>
                        </div>
                    </div>
                </div>

                {{-- Second Choice --}}
                <div class="p-6 bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl border-2 border-green-200">
                    <div class="flex items-center mb-4">
                        <span class="flex items-center justify-center w-8 h-8 bg-green-600 text-white rounded-full text-sm font-bold mr-3">2nd</span>
                        <h3 class="font-semibold text-gray-900">Second Choice</h3>
                        <span class="ml-2 text-xs bg-gray-200 text-gray-600 px-2 py-0.5 rounded-full">Optional</span>
                    </div>
                    <select name="program_id_2" id="program2" 
                        class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                        onchange="updateProgramDetails(2)">
                        <option value="">-- Select Second Choice (Optional) --</option>
                        @foreach($programs as $program)
                            <option value="{{ $program->id }}" 
                                data-level="{{ $program->level }}"
                                data-duration="{{ $program->duration_years }}"
                                data-requirements="{{ $program->requirements ?? 'None specified' }}"
                                data-tution="{{ $program->tuition_per_year }}">
                                {{ $program->name }} ({{ $program->code }})
                            </option>
                        @endforeach
                    </select>
                    <div id="program2Details" class="mt-4 hidden">
                        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                            <div class="bg-white p-3 rounded-lg">
                                <p class="text-gray-500">Level</p>
                                <p class="font-semibold text-gray-900" id="program2Level">-</p>
                            </div>
                            <div class="bg-white p-3 rounded-lg">
                                <p class="text-gray-500">Duration</p>
                                <p class="font-semibold text-gray-900" id="program2Duration">-</p>
                            </div>
                            <div class="bg-white p-3 rounded-lg">
                                <p class="text-gray-500">Tuition/Year</p>
                                <p class="font-semibold text-gray-900" id="program2Tuition">-</p>
                            </div>
                            <div class="bg-white p-3 rounded-lg">
                                <p class="text-gray-500">Requirements</p>
                                <p class="font-semibold text-gray-900" id="program2Requirements">-</p>
                            </div>
                        </div>
                    </div>
                </div>

                {{-- Third Choice --}}
                <div class="p-6 bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl border-2 border-purple-200">
                    <div class="flex items-center mb-4">
                        <span class="flex items-center justify-center w-8 h-8 bg-purple-600 text-white rounded-full text-sm font-bold mr-3">3rd</span>
                        <h3 class="font-semibold text-gray-900">Third Choice</h3>
                        <span class="ml-2 text-xs bg-gray-200 text-gray-600 px-2 py-0.5 rounded-full">Optional</span>
                    </div>
                    <select name="program_id_3" id="program3" 
                        class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                        onchange="updateProgramDetails(3)">
                        <option value="">-- Select Third Choice (Optional) --</option>
                        @foreach($programs as $program)
                            <option value="{{ $program->id }}" 
                                data-level="{{ $program->level }}"
                                data-duration="{{ $program->duration_years }}"
                                data-requirements="{{ $program->requirements ?? 'None specified' }}"
                                data-tution="{{ $program->tuition_per_year }}">
                                {{ $program->name }} ({{ $program->code }})
                            </option>
                        @endforeach
                    </select>
                    <div id="program3Details" class="mt-4 hidden">
                        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                            <div class="bg-white p-3 rounded-lg">
                                <p class="text-gray-500">Level</p>
                                <p class="font-semibold text-gray-900" id="program3Level">-</p>
                            </div>
                            <div class="bg-white p-3 rounded-lg">
                                <p class="text-gray-500">Duration</p>
                                <p class="font-semibold text-gray-900" id="program3Duration">-</p>
                            </div>
                            <div class="bg-white p-3 rounded-lg">
                                <p class="text-gray-500">Tuition/Year</p>
                                <p class="font-semibold text-gray-900" id="program3Tuition">-</p>
                            </div>
                            <div class="bg-white p-3 rounded-lg">
                                <p class="text-gray-500">Requirements</p>
                                <p class="font-semibold text-gray-900" id="program3Requirements">-</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {{-- Quick Info --}}
            <div class="bg-amber-50 border border-amber-200 rounded-xl p-6 mb-8">
                <h3 class="font-semibold text-amber-800 mb-3 flex items-center">
                    <i class="fas fa-info-circle mr-2"></i>
                    Before You Continue
                </h3>
                <ul class="text-sm text-amber-700 space-y-2">
                    <li class="flex items-start">
                        <i class="fas fa-check-circle text-green-500 mt-1 mr-2"></i>
                        Your first choice will be processed first. If not successful, we'll consider your second and third choices.
                    </li>
                    <li class="flex items-start">
                        <i class="fas fa-check-circle text-green-500 mt-1 mr-2"></i>
                        Application fee is KES {{ number_format(config('app-config.application_fee', 2000)) }} (non-refundable)
                    </li>
                    <li class="flex items-start">
                        <i class="fas fa-check-circle text-green-500 mt-1 mr-2"></i>
                        You can save your application as draft and continue later.
                    </li>
                </ul>
            </div>

            {{-- Eligibility Checker --}}
            <div class="mb-8">
                <button type="button" onclick="toggleEligibilityChecker()" class="flex items-center text-sm text-blue-600 hover:text-blue-800">
                    <i class="fas fa-search mr-2"></i>
                    Check Program Eligibility
                </button>
                
                <div id="eligibilityChecker" class="hidden mt-4 p-6 bg-gray-50 rounded-xl border border-gray-200">
                    <h4 class="font-semibold text-gray-900 mb-4">Quick Eligibility Check</h4>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Your KCSE Mean Grade</label>
                            <select id="checkGrade" class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                                <option value="">Select your grade</option>
                                <option value="A">A - Plain</option>
                                <option value="A-">A- (Minus)</option>
                                <option value="B+">B+ (Plus)</option>
                                <option value="B">B - Plain</option>
                                <option value="B-">B- (Minus)</option>
                                <option value="C+">C+ (Plus)</option>
                                <option value="C">C - Plain</option>
                                <option value="C-">C- (Minus)</option>
                                <option value="D+">D+ (Plus)</option>
                                <option value="D">D - Plain</option>
                                <option value="E">E</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Intended Level</label>
                            <select id="checkLevel" class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                                <option value="">Select level</option>
                                <option value="certificate">Certificate</option>
                                <option value="diploma">Diploma</option>
                                <option value="degree">Degree</option>
                            </select>
                        </div>
                    </div>
                    <button type="button" onclick="checkEligibility()" class="bg-[#00008B] text-white px-4 py-2 rounded-lg hover:bg-[#1e40af]">
                        Check Eligibility
                    </button>
                    <div id="eligibilityResults" class="mt-4 hidden">
                        <div class="p-4 rounded-lg" id="eligibilityResultBox"></div>
                    </div>
                </div>
            </div>

            {{-- Actions --}}
            <div class="flex justify-between items-center pt-6 border-t border-gray-200">
                <a href="{{ route('student.dashboard') }}" class="px-6 py-3 border border-gray-300 rounded-lg hover:bg-gray-50 text-gray-700">
                    {{ __('labels.cancel') }}
                </a>
                <button type="submit" class="bg-[#00008B] text-white px-8 py-3 rounded-lg hover:bg-[#1e40af] shadow-lg shadow-blue-200 font-semibold">
                    <i class="fas fa-arrow-right mr-2"></i>
                    Start Application
                </button>
            </div>
        </form>
    </div>
</div>

<script>
function updateProgramDetails(num) {
    const select = document.getElementById('program' + num);
    const detailsDiv = document.getElementById('program' + num + 'Details');
    const selectedOption = select.options[select.selectedIndex];
    
    if (select.value) {
        detailsDiv.classList.remove('hidden');
        document.getElementById('program' + num + 'Level').textContent = selectedOption.dataset.level ? ucfirst(selectedOption.dataset.level) : '-';
        document.getElementById('program' + num + 'Duration').textContent = selectedOption.dataset.duration ? selectedOption.dataset.duration + ' Years' : '-';
        document.getElementById('program' + num + 'Tuition').textContent = selectedOption.dataset.tution ? 'KES ' + numberFormat(selectedOption.dataset.tution) : '-';
        document.getElementById('program' + num + 'Requirements').textContent = selectedOption.dataset.requirements ? selectedOption.dataset.requirements.substring(0, 50) + '...' : '-';
    } else {
        detailsDiv.classList.add('hidden');
    }
}

function toggleEligibilityChecker() {
    const checker = document.getElementById('eligibilityChecker');
    checker.classList.toggle('hidden');
}

function checkEligibility() {
    const grade = document.getElementById('checkGrade').value;
    const level = document.getElementById('checkLevel').value;
    const resultsDiv = document.getElementById('eligibilityResults');
    const resultBox = document.getElementById('eligibilityResultBox');
    
    if (!grade || !level) {
        alert('Please select both your grade and intended level');
        return;
    }
    
    const gradePoints = {
        'A': 12, 'A-': 11, 'B+': 10, 'B': 9, 'B-': 8, 
        'C+': 7, 'C': 6, 'C-': 5, 'D+': 4, 'D': 3, 'E': 1
    };
    
    const requirements = {
        'certificate': 4,
        'diploma': 7,
        'degree': 9
    };
    
    const points = gradePoints[grade] || 0;
    const required = requirements[level] || 0;
    const eligible = points >= required;
    
    resultsDiv.classList.remove('hidden');
    
    if (eligible) {
        resultBox.className = 'p-4 rounded-lg bg-green-100 border border-green-200';
        resultBox.innerHTML = `
            <div class="flex items-center text-green-800">
                <i class="fas fa-check-circle text-2xl mr-3"></i>
                <div>
                    <p class="font-semibold">You're eligible for ${ucfirst(level)} programs!</p>
                    <p class="text-sm">Your grade (${grade}) meets the minimum requirement.</p>
                </div>
            </div>
        `;
    } else {
        resultBox.className = 'p-4 rounded-lg bg-yellow-100 border border-yellow-200';
        resultBox.innerHTML = `
            <div class="flex items-center text-yellow-800">
                <i class="fas fa-exclamation-triangle text-2xl mr-3"></i>
                <div>
                    <p class="font-semibold">You may not meet the requirements for ${ucfirst(level)} programs.</p>
                    <p class="text-sm">Your grade (${grade}) is below the typical requirement. You may want to consider lower-level programs first.</p>
                </div>
            </div>
        `;
    }
}

function ucfirst(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
}

function numberFormat(num) {
    return new Intl.NumberFormat('en-KE').format(num);
}
</script>
@endsection
