@extends('layouts.student')

@section('title', 'Dashboard')

@push('styles')
<style>
    .stat-card {
        transition: all 0.3s ease;
    }
    .stat-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1);
    }
</style>
@endpush

@section('content')
<div class="max-w-7xl mx-auto">
    {{-- Welcome Header --}}
    <div class="mb-8">
        <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
                <h1 class="text-3xl font-bold text-gray-900">{{ __('labels.welcome_back') }}, {{ auth()->user()->first_name }}!</h1>
                <p class="text-gray-600 mt-1">{{ __('labels.track_applications') }} - {{ now()->format('l, F j, Y') }}</p>
            </div>
            <a href="{{ route('student.application.create') }}" class="inline-flex items-center px-5 py-2.5 bg-[#00008B] text-white rounded-lg hover:bg-[#1e40af] transition-all font-medium shadow-lg shadow-blue-200">
                <i class="fas fa-plus mr-2"></i>
                {{ __('labels.new_application') }}
            </a>
        </div>
    </div>

    {{-- Stats Cards --}}
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-8">
        <div class="stat-card bg-white rounded-xl shadow-sm p-6 border-l-4 border-purple-500">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-gray-500">{{ __('labels.total_applications') }}</p>
                    <p class="text-3xl font-bold text-gray-900 mt-1">{{ $stats['total'] }}</p>
                </div>
                <div class="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
                    <i class="fas fa-file-alt text-purple-600 text-xl"></i>
                </div>
            </div>
            <div class="mt-3 flex items-center text-xs">
                <span class="text-gray-500">All time applications</span>
            </div>
        </div>

        <div class="stat-card bg-white rounded-xl shadow-sm p-6 border-l-4 border-yellow-500">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-gray-500">{{ __('labels.pending') }}</p>
                    <p class="text-3xl font-bold text-yellow-600 mt-1">{{ $stats['pending'] }}</p>
                </div>
                <div class="w-12 h-12 bg-yellow-100 rounded-xl flex items-center justify-center">
                    <i class="fas fa-clock text-yellow-600 text-xl"></i>
                </div>
            </div>
            <div class="mt-3 flex items-center text-xs">
                <span class="text-yellow-600">Awaiting review</span>
            </div>
        </div>

        <div class="stat-card bg-white rounded-xl shadow-sm p-6 border-l-4 border-green-500">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-gray-500">{{ __('labels.approved') }}</p>
                    <p class="text-3xl font-bold text-green-600 mt-1">{{ $stats['approved'] }}</p>
                </div>
                <div class="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                    <i class="fas fa-check-circle text-green-600 text-xl"></i>
                </div>
            </div>
            <div class="mt-3 flex items-center text-xs">
                <span class="text-green-600">Successfully admitted</span>
            </div>
        </div>

        <div class="stat-card bg-white rounded-xl shadow-sm p-6 border-l-4 border-blue-500">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-gray-500">{{ __('labels.draft') }}</p>
                    <p class="text-3xl font-bold text-blue-600 mt-1">{{ $stats['draft'] }}</p>
                </div>
                <div class="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                    <i class="fas fa-edit text-blue-600 text-xl"></i>
                </div>
            </div>
            <div class="mt-3 flex items-center text-xs">
                <span class="text-blue-600">In progress</span>
            </div>
        </div>
    </div>

    {{-- Main Content Grid --}}
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {{-- Applications Table --}}
        <div class="lg:col-span-2 bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            <div class="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
                <h2 class="text-lg font-semibold text-gray-900">{{ __('labels.my_applications') }}</h2>
                @if($applications->count() > 0)
                <span class="text-sm text-gray-500">{{ $applications->count() }} {{ __('labels.applications') }}</span>
                @endif
            </div>

            @if($applications->isEmpty())
            <div class="p-12 text-center">
                <div class="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i class="fas fa-file-alt text-gray-400 text-3xl"></i>
                </div>
                <h3 class="text-lg font-medium text-gray-900 mb-2">{{ __('labels.no_applications') }}</h3>
                <p class="text-gray-500 mb-6 max-w-sm mx-auto">{{ __('labels.start_application_prompt') }}</p>
                <a href="{{ route('student.application.create') }}" class="inline-flex items-center px-5 py-2.5 bg-[#00008B] text-white rounded-lg hover:bg-[#1e40af] transition-all font-medium">
                    <i class="fas fa-plus mr-2"></i>
                    {{ __('labels.start_application') }}
                </a>
            </div>
            @else
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">{{ __('labels.app_number') }}</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">{{ __('labels.program') }}</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">{{ __('labels.status') }}</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">{{ __('labels.payment') }}</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">{{ __('labels.actions') }}</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        @foreach($applications as $application)
                        <tr class="hover:bg-gray-50 transition-colors">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <a href="{{ route('student.application.show', $application->id) }}" class="font-medium text-[#00008B] hover:text-[#1e40af]">
                                    {{ $application->application_number }}
                                </a>
                            </td>
                            <td class="px-6 py-4">
                                <div class="font-medium text-gray-900">{{ $application->program->name ?? 'N/A' }}</div>
                                <div class="text-sm text-gray-500">{{ $application->program->code ?? '' }}</div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                @php
                                    $statusConfig = [
                                        'draft' => ['bg-gray-100 text-gray-700', 'Draft', 'far fa-edit'],
                                        'pending' => ['bg-yellow-100 text-yellow-700', 'Pending', 'far fa-clock'],
                                        'under_review' => ['bg-blue-100 text-blue-700', 'Under Review', 'far fa-search'],
                                        'approved' => ['bg-green-100 text-green-700', 'Approved', 'far fa-check-circle'],
                                        'rejected' => ['bg-red-100 text-red-700', 'Rejected', 'far fa-times-circle'],
                                        'info_requested' => ['bg-orange-100 text-orange-700', 'Info Requested', 'far fa-question-circle'],
                                    ];
                                    $config = $statusConfig[$application->status] ?? ['bg-gray-100 text-gray-700', ucfirst($application->status), 'far fa-circle'];
                                @endphp
                                <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium {{ $config[0] }}">
                                    <i class="{{ $config[2] }} mr-1"></i>
                                    {{ $config[1] }}
                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                @php
                                    $hasPayment = $application->payments()->where('status', 'completed')->exists();
                                @endphp
                                @if($hasPayment)
                                <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-green-100 text-green-700">
                                    <i class="fas fa-check mr-1"></i> Paid
                                </span>
                                @elseif($application->status !== 'draft')
                                <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-yellow-100 text-yellow-700">
                                    <i class="fas fa-clock mr-1"></i> Pending
                                </span>
                                @else
                                <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-500">
                                    <i class="fas fa-minus mr-1"></i> N/A
                                </span>
                                @endif
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="flex items-center space-x-2">
                                    @if($application->status === 'draft')
                                    <a href="{{ route('student.application.form', ['step' => $application->current_step ?? 'personal']) }}" 
                                       class="inline-flex items-center px-3 py-1.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-sm font-medium transition-colors">
                                        <i class="fas fa-edit mr-1"></i> {{ __('labels.continue') }}
                                    </a>
                                    <a href="{{ route('student.payment.show', $application->id) }}" 
                                       class="inline-flex items-center px-3 py-1.5 bg-green-600 text-white rounded-lg hover:bg-green-700 text-sm font-medium transition-colors">
                                        <i class="fas fa-credit-card mr-1"></i> {{ __('labels.pay_now') }}
                                    </a>
                                    @else
                                    <a href="{{ route('student.application.show', $application->id) }}" 
                                       class="inline-flex items-center px-3 py-1.5 bg-[#00008B] text-white rounded-lg hover:bg-[#1e40af] text-sm font-medium transition-colors">
                                        <i class="fas fa-eye mr-1"></i> {{ __('labels.view') }}
                                    </a>
                                    @endif
                                </div>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            @endif
        </div>

        {{-- Sidebar --}}
        <div class="space-y-6">
            {{-- Quick Actions --}}
            <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <h3 class="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                    <i class="fas fa-bolt text-yellow-500 mr-2"></i>
                    Quick Actions
                </h3>
                <div class="space-y-3">
                    <a href="{{ route('student.application.create') }}" class="flex items-center p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors group">
                        <div class="w-10 h-10 bg-[#00008B] rounded-lg flex items-center justify-center mr-3 group-hover:scale-110 transition-transform">
                            <i class="fas fa-plus text-white"></i>
                        </div>
                        <div>
                            <p class="font-medium text-gray-900">New Application</p>
                            <p class="text-xs text-gray-500">Apply for a new program</p>
                        </div>
                    </a>
                    
                    <a href="{{ route('student.profile.edit') }}" class="flex items-center p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors group">
                        <div class="w-10 h-10 bg-purple-600 rounded-lg flex items-center justify-center mr-3 group-hover:scale-110 transition-transform">
                            <i class="fas fa-user text-white"></i>
                        </div>
                        <div>
                            <p class="font-medium text-gray-900">Update Profile</p>
                            <p class="text-xs text-gray-500">Edit your information</p>
                        </div>
                    </a>

                    <a href="mailto:admissions@mutomocollege.ac.ke" class="flex items-center p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors group">
                        <div class="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center mr-3 group-hover:scale-110 transition-transform">
                            <i class="fas fa-headset text-white"></i>
                        </div>
                        <div>
                            <p class="font-medium text-gray-900">Get Help</p>
                            <p class="text-xs text-gray-500">Contact admissions</p>
                        </div>
                    </a>
                </div>
            </div>

            {{-- Application Tips --}}
            <div class="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl border border-blue-100 p-6">
                <h3 class="text-lg font-semibold text-blue-900 mb-3 flex items-center">
                    <i class="fas fa-lightbulb text-yellow-500 mr-2"></i>
                    Application Tips
                </h3>
                <ul class="space-y-2 text-sm text-blue-800">
                    <li class="flex items-start">
                        <i class="fas fa-check-circle text-green-500 mt-1 mr-2"></i>
                        Ensure all documents are clearly uploaded
                    </li>
                    <li class="flex items-start">
                        <i class="fas fa-check-circle text-green-500 mt-1 mr-2"></i>
                        Double-check your academic details
                    </li>
                    <li class="flex items-start">
                        <i class="fas fa-check-circle text-green-500 mt-1 mr-2"></i>
                        Pay application fee promptly
                    </li>
                    <li class="flex items-start">
                        <i class="fas fa-check-circle text-green-500 mt-1 mr-2"></i>
                        Check your email regularly for updates
                    </li>
                </ul>
            </div>

            {{-- Contact Support --}}
            <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <h3 class="text-lg font-semibold text-gray-900 mb-3 flex items-center">
                    <i class="fas fa-phone-alt text-green-500 mr-2"></i>
                    Need Help?
                </h3>
                <p class="text-sm text-gray-600 mb-4">
                    Our admissions team is ready to assist you with any questions.
                </p>
                <div class="space-y-2">
                    <a href="tel:+254700123456" class="flex items-center text-sm text-gray-700 hover:text-[#00008B] transition-colors">
                        <i class="fas fa-phone w-6 text-gray-400"></i>
                        +254 700 123 456
                    </a>
                    <a href="mailto:admissions@mutomocollege.ac.ke" class="flex items-center text-sm text-gray-700 hover:text-[#00008B] transition-colors">
                        <i class="fas fa-envelope w-6 text-gray-400"></i>
                        admissions@mutomocollege.ac.ke
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
