<div x-data="{
    relationship: '{{ $formData['guardian']['guardian_relationship'] ?? '' }}',
    showOtherRelationship: false,
    showAltContact: false,
    init() {
        this.updateVisibility();
    },
    updateVisibility() {
        this.showOtherRelationship = this.relationship === 'other';
        this.showAltContact = ['parent', 'guardian'].includes(this.relationship);
    }
}" class="space-y-4">
    <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Guardian/Parent Name *</label>
        <input type="text" name="guardian_name" value="{{ $formData['guardian']['guardian_name'] ?? '' }}" required
            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500">
    </div>

    <div class="grid grid-cols-2 gap-4">
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Relationship *</label>
            <select name="guardian_relationship" x-model="relationship" @change="updateVisibility()" required 
                class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                <option value="">Select</option>
                <option value="parent" {{ ($formData['guardian']['guardian_relationship'] ?? '') == 'parent' ? 'selected' : '' }}>Parent</option>
                <option value="guardian" {{ ($formData['guardian']['guardian_relationship'] ?? '') == 'guardian' ? 'selected' : '' }}>Guardian</option>
                <option value="sibling" {{ ($formData['guardian']['guardian_relationship'] ?? '') == 'sibling' ? 'selected' : '' }}>Sibling</option>
                <option value="relative" {{ ($formData['guardian']['guardian_relationship'] ?? '') == 'relative' ? 'selected' : '' }}>Relative</option>
                <option value="other" {{ ($formData['guardian']['guardian_relationship'] ?? '') == 'other' ? 'selected' : '' }}>Other</option>
            </select>
        </div>
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Phone Number *</label>
            <input type="tel" name="guardian_phone" value="{{ $formData['guardian']['guardian_phone'] ?? '' }}" required
                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
                placeholder="+254700000000">
        </div>
    </div>

    <div x-show="showOtherRelationship" x-transition>
        <label class="block text-sm font-medium text-gray-700 mb-1">Specify Relationship *</label>
        <input type="text" name="other_relationship" value="{{ $formData['guardian']['other_relationship'] ?? '' }}"
            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
            placeholder="Please specify your relationship to this person">
    </div>

    <div class="grid grid-cols-2 gap-4">
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Email</label>
            <input type="email" name="guardian_email" value="{{ $formData['guardian']['guardian_email'] ?? '' }}"
                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500">
        </div>
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Occupation</label>
            <input type="text" name="guardian_occupation" value="{{ $formData['guardian']['guardian_occupation'] ?? '' }}"
                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500">
        </div>
    </div>

    <div x-show="showAltContact" x-transition>
        <label class="flex items-center">
            <input type="checkbox" name="has_alternative_contact" value="1" 
                {{ ($formData['guardian']['has_alternative_contact'] ?? '') ? 'checked' : '' }}
                class="w-4 h-4 text-purple-600 border-gray-300 rounded">
            <span class="ml-2 text-sm text-gray-700">Add alternative contact</span>
        </label>
    </div>

    <div x-show="showAltContact" x-transition class="grid grid-cols-2 gap-4 pt-2">
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Alternative Phone</label>
            <input type="tel" name="alt_phone" value="{{ $formData['guardian']['alt_phone'] ?? '' }}"
                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
                placeholder="+254700000000">
        </div>
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Alternative Email</label>
            <input type="email" name="alt_email" value="{{ $formData['guardian']['alt_email'] ?? '' }}"
                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500">
        </div>
    </div>

    <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Address</label>
        <textarea name="guardian_address" rows="2" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500">{{ $formData['guardian']['guardian_address'] ?? '' }}</textarea>
    </div>
</div>
