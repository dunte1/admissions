<div class="space-y-4">
    <div class="grid grid-cols-2 gap-4">
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Date of Birth *</label>
            <input type="date" name="date_of_birth" value="{{ $formData['personal']['date_of_birth'] ?? '' }}" required
                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500">
        </div>
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Gender *</label>
            <select name="gender" required class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                <option value="">Select Gender</option>
                <option value="male" {{ ($formData['personal']['gender'] ?? '') == 'male' ? 'selected' : '' }}>Male</option>
                <option value="female" {{ ($formData['personal']['gender'] ?? '') == 'female' ? 'selected' : '' }}>Female</option>
                <option value="other" {{ ($formData['personal']['gender'] ?? '') == 'other' ? 'selected' : '' }}>Other</option>
            </select>
        </div>
    </div>

    <div class="grid grid-cols-2 gap-4">
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">ID/Passport Number</label>
            <input type="text" name="id_number" value="{{ $formData['personal']['id_number'] ?? '' }}"
                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
                placeholder="National ID or Passport">
        </div>
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Nationality *</label>
            <input type="text" name="nationality" value="{{ $formData['personal']['nationality'] ?? 'Kenyan' }}" required
                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500">
        </div>
    </div>

    <div class="grid grid-cols-2 gap-4">
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">County</label>
            <input type="text" name="county" value="{{ $formData['personal']['county'] ?? '' }}"
                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500">
        </div>
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">City</label>
            <input type="text" name="city" value="{{ $formData['personal']['city'] ?? '' }}"
                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500">
        </div>
    </div>

    <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Address</label>
        <textarea name="address" rows="2" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500">{{ $formData['personal']['address'] ?? '' }}</textarea>
    </div>

    <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Phone Number</label>
        <input type="tel" name="phone" value="{{ $formData['personal']['phone'] ?? auth()->user()->phone ?? '' }}"
            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
            placeholder="+254700000000">
    </div>
</div>
