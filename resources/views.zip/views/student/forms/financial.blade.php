<div x-data="{
    sponsorshipType: '{{ $formData['financial']['sponsorship_type'] ?? 'self' }}',
    showSponsorFields: false,
    init() {
        this.updateVisibility();
    },
    updateVisibility() {
        this.showSponsorFields = ['sponsored', 'government', 'corporate'].includes(this.sponsorshipType);
    }
}" class="space-y-6">
    <div class="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <p class="text-sm text-blue-800">Select your sponsorship type to help us process your application correctly.</p>
    </div>

    <div>
        <label class="block text-sm font-bold text-gray-700 mb-3">Sponsorship Type *</label>
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <label class="relative flex items-start p-4 border-2 border-gray-200 rounded-lg cursor-pointer hover:border-blue-300 transition-all" :class="sponsorshipType === 'self' ? 'border-blue-500 bg-blue-50' : ''">
                <input type="radio" name="sponsorship_type" value="self" x-model="sponsorshipType" @change="updateVisibility()" class="mt-1 mr-3">
                <div class="flex-1">
                    <div class="flex items-center mb-1">
                        <i class="fas fa-user text-blue-500 mr-2"></i>
                        <span class="font-semibold text-gray-900">Self-Sponsored</span>
                    </div>
                    <p class="text-xs text-gray-500">I'll fund my own studies</p>
                </div>
            </label>
            
            <label class="relative flex items-start p-4 border-2 border-gray-200 rounded-lg cursor-pointer hover:border-blue-300 transition-all" :class="sponsorshipType === 'sponsored' ? 'border-blue-500 bg-blue-50' : ''">
                <input type="radio" name="sponsorship_type" value="sponsored" x-model="sponsorshipType" @change="updateVisibility()" class="mt-1 mr-3">
                <div class="flex-1">
                    <div class="flex items-center mb-1">
                        <i class="fas fa-users text-green-500 mr-2"></i>
                        <span class="font-semibold text-gray-900">Sponsored</span>
                    </div>
                    <p class="text-xs text-gray-500">Individual/Organization sponsor</p>
                </div>
            </label>
            
            <label class="relative flex items-start p-4 border-2 border-gray-200 rounded-lg cursor-pointer hover:border-blue-300 transition-all" :class="sponsorshipType === 'government' ? 'border-blue-500 bg-blue-50' : ''">
                <input type="radio" name="sponsorship_type" value="government" x-model="sponsorshipType" @change="updateVisibility()" class="mt-1 mr-3">
                <div class="flex-1">
                    <div class="flex items-center mb-1">
                        <i class="fas fa-landmark text-red-500 mr-2"></i>
                        <span class="font-semibold text-gray-900">Government</span>
                    </div>
                    <p class="text-xs text-gray-500">Government scholarship/sponsorship</p>
                </div>
            </label>
            
            <label class="relative flex items-start p-4 border-2 border-gray-200 rounded-lg cursor-pointer hover:border-blue-300 transition-all" :class="sponsorshipType === 'corporate' ? 'border-blue-500 bg-blue-50' : ''">
                <input type="radio" name="sponsorship_type" value="corporate" x-model="sponsorshipType" @change="updateVisibility()" class="mt-1 mr-3">
                <div class="flex-1">
                    <div class="flex items-center mb-1">
                        <i class="fas fa-building text-purple-500 mr-2"></i>
                        <span class="font-semibold text-gray-900">Corporate</span>
                    </div>
                    <p class="text-xs text-gray-500">Company/Employer sponsorship</p>
                </div>
            </label>
        </div>
    </div>

    <div x-show="showSponsorFields" x-transition class="space-y-4">
        <div class="border-t border-gray-200 pt-6">
            <h4 class="text-sm font-bold text-gray-700 mb-4 flex items-center">
                <i class="fas fa-info-circle text-blue-500 mr-2"></i>
                Sponsor Information
            </h4>
            
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Sponsor Name *</label>
                    <input type="text" name="sponsor_name" value="{{ $formData['financial']['sponsor_name'] ?? '' }}"
                        class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                        placeholder="Full name or organization">
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Sponsor Phone</label>
                    <input type="tel" name="sponsor_phone" value="{{ $formData['financial']['sponsor_phone'] ?? '' }}"
                        class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                        placeholder="+254700000000">
                </div>
            </div>
            
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Sponsor Email</label>
                    <input type="email" name="sponsor_email" value="{{ $formData['financial']['sponsor_email'] ?? '' }}"
                        class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                        placeholder="sponsor@example.com">
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Sponsor Address</label>
                    <input type="text" name="sponsor_address" value="{{ $formData['financial']['sponsor_address'] ?? '' }}"
                        class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                        placeholder="Physical address">
                </div>
            </div>

            <div class="mt-4">
                <label class="block text-sm font-medium text-gray-700 mb-1">Relationship/Type</label>
                <input type="text" name="sponsor_relationship" value="{{ $formData['financial']['sponsor_relationship'] ?? '' }}"
                    class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="e.g., Parent, Employer, NGO, County Government">
            </div>
        </div>
    </div>

    <div class="bg-gray-50 rounded-lg p-4 mt-6">
        <h4 class="text-sm font-bold text-gray-700 mb-3 flex items-center">
            <i class="fas fa-money-bill-wave text-green-500 mr-2"></i>
            Application Fee
        </h4>
        <div class="flex items-center justify-between">
            <div>
                <p class="text-sm text-gray-600">Application processing fee</p>
                <p class="text-xs text-gray-500">Non-refundable upon submission</p>
            </div>
            <div class="text-right">
                <p class="text-2xl font-bold text-gray-900">KES 1,000</p>
                <p class="text-xs text-gray-500">Payable via M-PESA</p>
            </div>
        </div>
    </div>
</div>
