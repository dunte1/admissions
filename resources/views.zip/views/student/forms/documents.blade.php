<div x-data="{
    files: {},
    previews: {},
    maxSize: 5 * 1024 * 1024, // 5MB
    init() {
        // Initialize existing files from application
        @foreach(['id_document', 'certificate', 'photo', 'birth_certificate', 'results_slip'] as $docType)
            @if(isset($application) && $application->documents->where('type', $docType)->first())
                this.files['{{ $docType }}'] = { name: '{{ $application->documents->where('type', $docType)->first()->original_name ?? $docType }}', uploaded: true };
            @endif
        @endforeach
    },
    handleFileUpload(fieldName, event) {
        const file = event.target.files[0];
        if (!file) return;
        
        if (file.size > this.maxSize) {
            alert('File size exceeds 5MB limit');
            event.target.value = '';
            return;
        }
        
        this.files[fieldName] = file;
        
        // Create preview for images
        if (file.type.startsWith('image/')) {
            const reader = new FileReader();
            reader.onload = (e) => {
                this.previews[fieldName] = e.target.result;
                this.$refs[fieldName + 'Preview'].src = e.target.result;
                this.$refs[fieldName + 'Preview'].classList.remove('hidden');
            };
            reader.readAsDataURL(file);
        }
    },
    handleDrop(fieldName, event) {
        event.preventDefault();
        const file = event.dataTransfer.files[0];
        if (!file) return;
        
        if (file.size > this.maxSize) {
            alert('File size exceeds 5MB limit');
            return;
        }
        
        this.files[fieldName] = file;
        
        // Update the file input
        const input = document.getElementById(fieldName);
        const dataTransfer = new DataTransfer();
        dataTransfer.items.add(file);
        input.files = dataTransfer.files;
        
        // Create preview for images
        if (file.type.startsWith('image/')) {
            const reader = new FileReader();
            reader.onload = (e) => {
                this.previews[fieldName] = e.target.result;
                this.$refs[fieldName + 'Preview'].src = e.target.result;
                this.$refs[fieldName + 'Preview'].classList.remove('hidden');
            };
            reader.readAsDataURL(file);
        }
        
        // Remove drag-over styling
        event.target.closest('.drop-zone').classList.remove('border-purple-500', 'bg-purple-50');
    },
    handleDragOver(event) {
        event.preventDefault();
        event.target.closest('.drop-zone').classList.add('border-purple-500', 'bg-purple-50');
    },
    handleDragLeave(event) {
        event.target.closest('.drop-zone').classList.remove('border-purple-500', 'bg-purple-50');
    },
    removeFile(fieldName) {
        delete this.files[fieldName];
        delete this.previews[fieldName];
        document.getElementById(fieldName).value = '';
        const preview = this.$refs[fieldName + 'Preview'];
        if (preview) preview.classList.add('hidden');
    },
    getFileIcon(type) {
        if (!type) return 'fa-file';
        if (type.startsWith('image/')) return 'fa-image';
        if (type.includes('pdf')) return 'fa-file-pdf';
        return 'fa-file-alt';
    },
    formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }
}" class="space-y-6">

    {{-- Upload Guidelines --}}
    <div class="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-xl p-5">
        <div class="flex items-start">
            <div class="flex-shrink-0">
                <i class="fas fa-info-circle text-blue-600 text-xl mt-0.5"></i>
            </div>
            <div class="ml-3">
                <h4 class="text-sm font-semibold text-blue-900">Upload Requirements</h4>
                <ul class="mt-2 text-sm text-blue-800 space-y-1">
                    <li>• Accepted formats: PDF, JPG, JPEG, PNG</li>
                    <li>• Maximum file size: 5MB per document</li>
                    <li>• Ensure documents are clear and readable</li>
                    <li>• Files can be uploaded via drag & drop or click to browse</li>
                </ul>
            </div>
        </div>
    </div>

    {{-- Required Documents --}}
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {{-- ID Document --}}
        <div class="bg-white rounded-xl border border-gray-200 p-5">
            <div class="flex items-center justify-between mb-4">
                <div class="flex items-center">
                    <div class="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center mr-3">
                        <i class="fas fa-id-card text-red-600"></i>
                    </div>
                    <div>
                        <h4 class="font-semibold text-gray-900">ID Document / Passport</h4>
                        <p class="text-xs text-gray-500">National ID or valid Passport</p>
                    </div>
                </div>
                <span class="text-xs bg-red-100 text-red-700 px-2 py-1 rounded-full font-medium">Required</span>
            </div>
            <div class="drop-zone relative border-2 border-dashed border-gray-300 rounded-xl p-6 text-center hover:border-purple-500 transition-all cursor-pointer"
                x-on:drop="handleDrop('id_document', $event)"
                x-on:dragover="handleDragOver($event)"
                x-on:dragleave="handleDragLeave($event)">
                
                <template x-if="!files.id_document">
                    <div>
                        <i class="fas fa-cloud-upload-alt text-4xl text-gray-400 mb-3"></i>
                        <p class="text-sm text-gray-600 mb-2">Drag & drop or click to upload</p>
                        <label class="inline-block bg-[#00008B] text-white px-4 py-2 rounded-lg text-sm cursor-pointer hover:bg-[#1e40af] transition-colors">
                            Choose File
                            <input type="file" id="id_document" name="id_document" class="hidden" accept=".pdf,.jpg,.jpeg,.png"
                                x-on:change="handleFileUpload('id_document', $event)">
                        </label>
                        <p class="text-xs text-gray-400 mt-2">PDF, JPG, PNG (max 5MB)</p>
                    </div>
                </template>
                
                <template x-if="files.id_document && files.id_document.uploaded">
                    <div class="flex items-center justify-center">
                        <div class="text-center">
                            <i class="fas fa-check-circle text-4xl text-green-500 mb-2"></i>
                            <p class="text-sm text-green-700 font-medium" x-text="files.id_document?.name"></p>
                            <p class="text-xs text-green-600">Already uploaded</p>
                        </div>
                    </div>
                </template>
                
                <template x-if="files.id_document && !files.id_document.uploaded && files.id_document.name">
                    <div class="space-y-3">
                        <img x-ref="id_documentPreview" class="hidden max-h-32 mx-auto rounded-lg shadow-sm">
                        <div class="flex items-center justify-center space-x-2">
                            <i class="fas text-gray-500" :class="getFileIcon(files.id_document.type)"></i>
                            <p class="text-sm text-gray-700 font-medium" x-text="files.id_document.name"></p>
                        </div>
                        <p class="text-xs text-gray-500" x-text="formatFileSize(files.id_document.size)"></p>
                        <button type="button" class="text-red-600 hover:text-red-800 text-sm font-medium" x-on:click="removeFile('id_document')">
                            <i class="fas fa-trash mr-1"></i> Remove
                        </button>
                    </div>
                </template>
            </div>
        </div>

        {{-- KCSE Certificate --}}
        <div class="bg-white rounded-xl border border-gray-200 p-5">
            <div class="flex items-center justify-between mb-4">
                <div class="flex items-center">
                    <div class="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center mr-3">
                        <i class="fas fa-certificate text-purple-600"></i>
                    </div>
                    <div>
                        <h4 class="font-semibold text-gray-900">KCSE Certificate</h4>
                        <p class="text-xs text-gray-500">Academic certificate or results slip</p>
                    </div>
                </div>
                <span class="text-xs bg-red-100 text-red-700 px-2 py-1 rounded-full font-medium">Required</span>
            </div>
            <div class="drop-zone relative border-2 border-dashed border-gray-300 rounded-xl p-6 text-center hover:border-purple-500 transition-all cursor-pointer"
                x-on:drop="handleDrop('certificate', $event)"
                x-on:dragover="handleDragOver($event)"
                x-on:dragleave="handleDragLeave($event)">
                
                <template x-if="!files.certificate">
                    <div>
                        <i class="fas fa-cloud-upload-alt text-4xl text-gray-400 mb-3"></i>
                        <p class="text-sm text-gray-600 mb-2">Drag & drop or click to upload</p>
                        <label class="inline-block bg-[#00008B] text-white px-4 py-2 rounded-lg text-sm cursor-pointer hover:bg-[#1e40af] transition-colors">
                            Choose File
                            <input type="file" id="certificate" name="certificate" class="hidden" accept=".pdf,.jpg,.jpeg,.png"
                                x-on:change="handleFileUpload('certificate', $event)">
                        </label>
                        <p class="text-xs text-gray-400 mt-2">PDF, JPG, PNG (max 5MB)</p>
                    </div>
                </template>
                
                <template x-if="files.certificate && files.certificate.uploaded">
                    <div class="flex items-center justify-center">
                        <div class="text-center">
                            <i class="fas fa-check-circle text-4xl text-green-500 mb-2"></i>
                            <p class="text-sm text-green-700 font-medium" x-text="files.certificate?.name"></p>
                            <p class="text-xs text-green-600">Already uploaded</p>
                        </div>
                    </div>
                </template>
                
                <template x-if="files.certificate && !files.certificate.uploaded && files.certificate.name">
                    <div class="space-y-3">
                        <img x-ref="certificatePreview" class="hidden max-h-32 mx-auto rounded-lg shadow-sm">
                        <div class="flex items-center justify-center space-x-2">
                            <i class="fas text-gray-500" :class="getFileIcon(files.certificate.type)"></i>
                            <p class="text-sm text-gray-700 font-medium" x-text="files.certificate.name"></p>
                        </div>
                        <p class="text-xs text-gray-500" x-text="formatFileSize(files.certificate.size)"></p>
                        <button type="button" class="text-red-600 hover:text-red-800 text-sm font-medium" x-on:click="removeFile('certificate')">
                            <i class="fas fa-trash mr-1"></i> Remove
                        </button>
                    </div>
                </template>
            </div>
        </div>

        {{-- Passport Photo --}}
        <div class="bg-white rounded-xl border border-gray-200 p-5">
            <div class="flex items-center justify-between mb-4">
                <div class="flex items-center">
                    <div class="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center mr-3">
                        <i class="fas fa-camera text-blue-600"></i>
                    </div>
                    <div>
                        <h4 class="font-semibold text-gray-900">Passport Photo</h4>
                        <p class="text-xs text-gray-500">Recent passport-size photo</p>
                    </div>
                </div>
                <span class="text-xs bg-red-100 text-red-700 px-2 py-1 rounded-full font-medium">Required</span>
            </div>
            <div class="drop-zone relative border-2 border-dashed border-gray-300 rounded-xl p-6 text-center hover:border-purple-500 transition-all cursor-pointer"
                x-on:drop="handleDrop('photo', $event)"
                x-on:dragover="handleDragOver($event)"
                x-on:dragleave="handleDragLeave($event)">
                
                <template x-if="!files.photo">
                    <div>
                        <i class="fas fa-cloud-upload-alt text-4xl text-gray-400 mb-3"></i>
                        <p class="text-sm text-gray-600 mb-2">Drag & drop or click to upload</p>
                        <label class="inline-block bg-[#00008B] text-white px-4 py-2 rounded-lg text-sm cursor-pointer hover:bg-[#1e40af] transition-colors">
                            Choose File
                            <input type="file" id="photo" name="photo" class="hidden" accept=".jpg,.jpeg,.png"
                                x-on:change="handleFileUpload('photo', $event)">
                        </label>
                        <p class="text-xs text-gray-400 mt-2">JPG, PNG (max 2MB)</p>
                    </div>
                </template>
                
                <template x-if="files.photo && files.photo.uploaded">
                    <div class="text-center">
                        <img x-ref="photoPreviewExisting" class="w-24 h-24 object-cover rounded-lg mx-auto mb-2 border border-gray-200" 
                             src="{{ $application->documents->where('type', 'photo')->first() ? Storage::url($application->documents->where('type', 'photo')->first()->stored_path) : '' }}" alt="Passport Photo">
                        <p class="text-sm text-green-700 font-medium">Photo uploaded</p>
                    </div>
                </template>
                
                <template x-if="files.photo && !files.photo.uploaded && files.photo.name">
                    <div class="space-y-3">
                        <img x-ref="photoPreview" class="hidden max-h-32 mx-auto rounded-lg shadow-sm">
                        <div class="flex items-center justify-center space-x-2">
                            <i class="fas text-gray-500" :class="getFileIcon(files.photo.type)"></i>
                            <p class="text-sm text-gray-700 font-medium" x-text="files.photo.name"></p>
                        </div>
                        <p class="text-xs text-gray-500" x-text="formatFileSize(files.photo.size)"></p>
                        <button type="button" class="text-red-600 hover:text-red-800 text-sm font-medium" x-on:click="removeFile('photo')">
                            <i class="fas fa-trash mr-1"></i> Remove
                        </button>
                    </div>
                </template>
            </div>
        </div>

        {{-- Birth Certificate --}}
        <div class="bg-white rounded-xl border border-gray-200 p-5">
            <div class="flex items-center justify-between mb-4">
                <div class="flex items-center">
                    <div class="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center mr-3">
                        <i class="fas fa-birthday-cake text-green-600"></i>
                    </div>
                    <div>
                        <h4 class="font-semibold text-gray-900">Birth Certificate</h4>
                        <p class="text-xs text-gray-500">Official birth certificate</p>
                    </div>
                </div>
                <span class="text-xs bg-yellow-100 text-yellow-700 px-2 py-1 rounded-full font-medium">Recommended</span>
            </div>
            <div class="drop-zone relative border-2 border-dashed border-gray-300 rounded-xl p-6 text-center hover:border-purple-500 transition-all cursor-pointer"
                x-on:drop="handleDrop('birth_certificate', $event)"
                x-on:dragover="handleDragOver($event)"
                x-on:dragleave="handleDragLeave($event)">
                
                <template x-if="!files.birth_certificate">
                    <div>
                        <i class="fas fa-cloud-upload-alt text-4xl text-gray-400 mb-3"></i>
                        <p class="text-sm text-gray-600 mb-2">Drag & drop or click to upload</p>
                        <label class="inline-block bg-[#00008B] text-white px-4 py-2 rounded-lg text-sm cursor-pointer hover:bg-[#1e40af] transition-colors">
                            Choose File
                            <input type="file" id="birth_certificate" name="birth_certificate" class="hidden" accept=".pdf,.jpg,.jpeg,.png"
                                x-on:change="handleFileUpload('birth_certificate', $event)">
                        </label>
                        <p class="text-xs text-gray-400 mt-2">PDF, JPG, PNG (max 5MB)</p>
                    </div>
                </template>
                
                <template x-if="files.birth_certificate && files.birth_certificate.uploaded">
                    <div class="flex items-center justify-center">
                        <div class="text-center">
                            <i class="fas fa-check-circle text-4xl text-green-500 mb-2"></i>
                            <p class="text-sm text-green-700 font-medium" x-text="files.birth_certificate?.name"></p>
                            <p class="text-xs text-green-600">Already uploaded</p>
                        </div>
                    </div>
                </template>
                
                <template x-if="files.birth_certificate && !files.birth_certificate.uploaded && files.birth_certificate.name">
                    <div class="space-y-3">
                        <img x-ref="birth_certificatePreview" class="hidden max-h-32 mx-auto rounded-lg shadow-sm">
                        <div class="flex items-center justify-center space-x-2">
                            <i class="fas text-gray-500" :class="getFileIcon(files.birth_certificate.type)"></i>
                            <p class="text-sm text-gray-700 font-medium" x-text="files.birth_certificate.name"></p>
                        </div>
                        <p class="text-xs text-gray-500" x-text="formatFileSize(files.birth_certificate.size)"></p>
                        <button type="button" class="text-red-600 hover:text-red-800 text-sm font-medium" x-on:click="removeFile('birth_certificate')">
                            <i class="fas fa-trash mr-1"></i> Remove
                        </button>
                    </div>
                </template>
            </div>
        </div>

        {{-- Results Slip --}}
        <div class="bg-white rounded-xl border border-gray-200 p-5">
            <div class="flex items-center justify-between mb-4">
                <div class="flex items-center">
                    <div class="w-10 h-10 bg-amber-100 rounded-lg flex items-center justify-center mr-3">
                        <i class="fas fa-file-alt text-amber-600"></i>
                    </div>
                    <div>
                        <h4 class="font-semibold text-gray-900">Results Slip</h4>
                        <p class="text-xs text-gray-500">KCSE Result Slip (with grades)</p>
                    </div>
                </div>
                <span class="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded-full font-medium">Optional</span>
            </div>
            <div class="drop-zone relative border-2 border-dashed border-gray-300 rounded-xl p-6 text-center hover:border-purple-500 transition-all cursor-pointer"
                x-on:drop="handleDrop('results_slip', $event)"
                x-on:dragover="handleDragOver($event)"
                x-on:dragleave="handleDragLeave($event)">
                
                <template x-if="!files.results_slip">
                    <div>
                        <i class="fas fa-cloud-upload-alt text-4xl text-gray-400 mb-3"></i>
                        <p class="text-sm text-gray-600 mb-2">Drag & drop or click to upload</p>
                        <label class="inline-block bg-[#00008B] text-white px-4 py-2 rounded-lg text-sm cursor-pointer hover:bg-[#1e40af] transition-colors">
                            Choose File
                            <input type="file" id="results_slip" name="results_slip" class="hidden" accept=".pdf,.jpg,.jpeg,.png"
                                x-on:change="handleFileUpload('results_slip', $event)">
                        </label>
                        <p class="text-xs text-gray-400 mt-2">PDF, JPG, PNG (max 5MB)</p>
                    </div>
                </template>
                
                <template x-if="files.results_slip && files.results_slip.uploaded">
                    <div class="flex items-center justify-center">
                        <div class="text-center">
                            <i class="fas fa-check-circle text-4xl text-green-500 mb-2"></i>
                            <p class="text-sm text-green-700 font-medium" x-text="files.results_slip?.name"></p>
                            <p class="text-xs text-green-600">Already uploaded</p>
                        </div>
                    </div>
                </template>
                
                <template x-if="files.results_slip && !files.results_slip.uploaded && files.results_slip.name">
                    <div class="space-y-3">
                        <img x-ref="results_slipPreview" class="hidden max-h-32 mx-auto rounded-lg shadow-sm">
                        <div class="flex items-center justify-center space-x-2">
                            <i class="fas text-gray-500" :class="getFileIcon(files.results_slip.type)"></i>
                            <p class="text-sm text-gray-700 font-medium" x-text="files.results_slip.name"></p>
                        </div>
                        <p class="text-xs text-gray-500" x-text="formatFileSize(files.results_slip.size)"></p>
                        <button type="button" class="text-red-600 hover:text-red-800 text-sm font-medium" x-on:click="removeFile('results_slip')">
                            <i class="fas fa-trash mr-1"></i> Remove
                        </button>
                    </div>
                </template>
            </div>
        </div>
    </div>

    {{-- Upload Progress Summary --}}
    <div class="bg-gray-50 rounded-xl p-4 border border-gray-200">
        <h4 class="font-semibold text-gray-700 mb-3">Upload Summary</h4>
        <div class="grid grid-cols-2 md:grid-cols-5 gap-3">
            <div class="text-center p-3 bg-white rounded-lg">
                <template x-if="files.id_document">
                    <i class="fas fa-check-circle text-green-500 text-xl"></i>
                </template>
                <template x-if="!files.id_document">
                    <i class="fas fa-times-circle text-gray-400 text-xl"></i>
                </template>
                <p class="text-xs text-gray-600 mt-1">ID Document</p>
            </div>
            <div class="text-center p-3 bg-white rounded-lg">
                <template x-if="files.certificate">
                    <i class="fas fa-check-circle text-green-500 text-xl"></i>
                </template>
                <template x-if="!files.certificate">
                    <i class="fas fa-times-circle text-gray-400 text-xl"></i>
                </template>
                <p class="text-xs text-gray-600 mt-1">Certificate</p>
            </div>
            <div class="text-center p-3 bg-white rounded-lg">
                <template x-if="files.photo">
                    <i class="fas fa-check-circle text-green-500 text-xl"></i>
                </template>
                <template x-if="!files.photo">
                    <i class="fas fa-times-circle text-gray-400 text-xl"></i>
                </template>
                <p class="text-xs text-gray-600 mt-1">Photo</p>
            </div>
            <div class="text-center p-3 bg-white rounded-lg">
                <template x-if="files.birth_certificate">
                    <i class="fas fa-check-circle text-green-500 text-xl"></i>
                </template>
                <template x-if="!files.birth_certificate">
                    <i class="fas fa-times-circle text-gray-400 text-xl"></i>
                </template>
                <p class="text-xs text-gray-600 mt-1">Birth Cert</p>
            </div>
            <div class="text-center p-3 bg-white rounded-lg col-span-2 md:col-span-1">
                <template x-if="files.results_slip">
                    <i class="fas fa-check-circle text-green-500 text-xl"></i>
                </template>
                <template x-if="!files.results_slip">
                    <i class="fas fa-times-circle text-gray-400 text-xl"></i>
                </template>
                <p class="text-xs text-gray-600 mt-1">Results Slip</p>
            </div>
        </div>
    </div>
</div>
