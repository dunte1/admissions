<div x-data="{
    educationLevel: '{{ $formData['academic']['education_level'] ?? '' }}',
    showKcseFields: false,
    showGradeFields: false,
    showSubjects: false,
    requiredSubjects: ['Mathematics', 'English', 'Biology', 'Chemistry', 'Physics'],
    init() {
        this.updateVisibility();
    },
    updateVisibility() {
        this.showKcseFields = ['kcse', 'igcse'].includes(this.educationLevel);
        this.showGradeFields = ['diploma', 'degree'].includes(this.educationLevel);
        this.showSubjects = this.educationLevel === 'kcse';
    },
    calculateMeanGrade() {
        const subjects = ['mathematics', 'english', 'kiswahili', 'biology', 'chemistry', 'physics', 'geography', 'history', 'cre', 'agriculture', 'business', 'computer'];
        const gradePoints = {
            'A': 12, 'A-': 11, 'B+': 10, 'B': 9, 'B-': 8, 
            'C+': 7, 'C': 6, 'C-': 5, 'D+': 4, 'D': 3, 'D-': 2, 'E': 1
        };
        
        let totalPoints = 0;
        let count = 0;
        
        subjects.forEach(subject => {
            const grade = document.querySelector(`[name='subjects[${subject}]']`)?.value;
            if (grade && gradePoints[grade] !== undefined) {
                totalPoints += gradePoints[grade];
                count++;
            }
        });
        
        if (count > 0) {
            const avgPoints = totalPoints / count;
            let meanGrade = '';
            
            if (avgPoints >= 11.5) meanGrade = 'A';
            else if (avgPoints >= 10.5) meanGrade = 'A-';
            else if (avgPoints >= 9.5) meanGrade = 'B+';
            else if (avgPoints >= 8.5) meanGrade = 'B';
            else if (avgPoints >= 7.5) meanGrade = 'B-';
            else if (avgPoints >= 6.5) meanGrade = 'C+';
            else if (avgPoints >= 5.5) meanGrade = 'C';
            else if (avgPoints >= 4.5) meanGrade = 'C-';
            else if (avgPoints >= 3.5) meanGrade = 'D+';
            else if (avgPoints >= 2.5) meanGrade = 'D';
            else meanGrade = 'E';
            
            document.querySelector('[name=\"mean_grade\"]').value = meanGrade;
            document.querySelector('[name=\"average_grade\"]').value = meanGrade;
        }
    }
}" class="space-y-6">
    
    {{-- Education Level --}}
    <div>
        <label class="block text-sm font-bold text-gray-700 mb-2">Highest Education Level *</label>
        <select name="education_level" x-model="educationLevel" @change="updateVisibility()" required 
            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500">
            <option value="">Select Level</option>
            <option value="kcse" {{ ($formData['academic']['education_level'] ?? '') == 'kcse' ? 'selected' : '' }}>KCSE (Kenya Certificate of Secondary Education)</option>
            <option value="igcse" {{ ($formData['academic']['education_level'] ?? '') == 'igcse' ? 'selected' : '' }}>IGCSE (International)</option>
            <option value="diploma" {{ ($formData['academic']['education_level'] ?? '') == 'diploma' ? 'selected' : '' }}>Diploma</option>
            <option value="degree" {{ ($formData['academic']['education_level'] ?? '') == 'degree' ? 'selected' : '' }}>Degree</option>
            <option value="other" {{ ($formData['academic']['education_level'] ?? '') == 'other' ? 'selected' : '' }}>Other</option>
        </select>
    </div>

    {{-- Institution Details --}}
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
            <label class="block text-sm font-bold text-gray-700 mb-2">Institution Name *</label>
            <input type="text" name="institution_name" value="{{ $formData['academic']['institution_name'] ?? '' }}" required
                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                placeholder="Name of school/college/university">
        </div>
        <div>
            <label class="block text-sm font-bold text-gray-700 mb-2">Certificate Type *</label>
            <input type="text" name="certificate_type" value="{{ $formData['academic']['certificate_type'] ?? '' }}" required
                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                placeholder="e.g., KCSE, BSc, Diploma">
        </div>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
            <label class="block text-sm font-bold text-gray-700 mb-2">Year of Completion *</label>
            <input type="number" name="year_of_completion" value="{{ $formData['academic']['year_of_completion'] ?? '' }}" required
                min="1990" max="{{ date('Y') }}" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500">
        </div>
        <div x-show="showKcseFields" x-transition>
            <label class="block text-sm font-bold text-gray-700 mb-2">KCSE Index Number</label>
            <input type="text" name="kcse_index" value="{{ $formData['academic']['kcse_index'] ?? '' }}"
                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                placeholder="Enter your KCSE index number">
        </div>
    </div>

    {{-- KCSE Subject Grades --}}
    <div x-show="showSubjects" x-transition class="space-y-4">
        <div class="bg-gradient-to-r from-purple-50 to-indigo-50 rounded-xl p-6 border border-purple-200">
            <h4 class="font-bold text-gray-900 mb-4 flex items-center">
                <i class="fas fa-graduation-cap text-purple-600 mr-2"></i>
                KCSE Subject Grades
            </h4>
            <p class="text-sm text-gray-600 mb-4">Enter your grades for each subject. The system will automatically calculate your mean grade.</p>
            
            <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                @php
                    $subjects = [
                        'mathematics' => 'Mathematics',
                        'english' => 'English',
                        'kiswahili' => 'Kiswahili',
                        'biology' => 'Biology',
                        'chemistry' => 'Chemistry',
                        'physics' => 'Physics',
                        'geography' => 'Geography',
                        'history' => 'History & Government',
                        'cre' => 'CRE (Christian Religious Ed)',
                        'ire' => 'IRE (Islamic Religious Ed)',
                        'hindu' => 'HRE (Hindu Religious Ed)',
                        'agriculture' => 'Agriculture',
                        'business' => 'Business Studies',
                        'computer' => 'Computer Studies',
                        'home_science' => 'Home Science',
                        'woodwork' => 'Woodwork',
                        'metalwork' => 'Metalwork',
                        'art' => 'Art & Design',
                        'music' => 'Music',
                    ];
                    
                    $grades = ['A', 'A-', 'B+', 'B', 'B-', 'C+', 'C', 'C-', 'D+', 'D', 'D-', 'E'];
                @endphp
                
                @foreach($subjects as $key => $subjectName)
                <div>
                    <label class="block text-xs font-medium text-gray-600 mb-1">{{ $subjectName }}</label>
                    <select name="subjects[{{ $key }}]" @change="calculateMeanGrade()" 
                        class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 focus:border-purple-500">
                        <option value="">-</option>
                        @foreach($grades as $grade)
                            <option value="{{ $grade }}" {{ ($formData['academic']['subjects'][$key] ?? '') == $grade ? 'selected' : '' }}>{{ $grade }}</option>
                        @endforeach
                    </select>
                </div>
                @endforeach
            </div>
            
            <div class="mt-6 flex items-center justify-between p-4 bg-white rounded-lg border border-purple-200">
                <div>
                    <p class="text-sm text-gray-600">Calculated Mean Grade</p>
                    <p class="text-xs text-gray-500">Auto-calculated from your grades</p>
                </div>
                <div class="text-right">
                    <input type="hidden" name="mean_grade" value="{{ $formData['academic']['mean_grade'] ?? '' }}">
                    <input type="hidden" name="average_grade" value="{{ $formData['academic']['average_grade'] ?? '' }}">
                    <span class="text-3xl font-bold text-purple-600" id="calculatedMeanGrade">
                        {{ $formData['academic']['mean_grade'] ?? '-' }}
                    </span>
                </div>
            </div>
        </div>
    </div>

    {{-- Mean Grade for KCSE (Manual Entry if no subjects) --}}
    <div x-show="showKcseFields && !showSubjects" x-transition>
        <label class="block text-sm font-bold text-gray-700 mb-2">Mean Grade</label>
        <select name="mean_grade" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500">
            <option value="">Select your mean grade</option>
            @php $grades = ['A', 'A-', 'B+', 'B', 'B-', 'C+', 'C', 'C-', 'D+', 'D', 'E']; @endphp
            @foreach($grades as $grade)
                <option value="{{ $grade }}" {{ ($formData['academic']['mean_grade'] ?? '') == $grade ? 'selected' : '' }}>{{ $grade }}</option>
            @endforeach
        </select>
    </div>

    {{-- GPA for Higher Education --}}
    <div x-show="showGradeFields" x-transition class="space-y-4">
        <div>
            <label class="block text-sm font-bold text-gray-700 mb-2">GPA / Score *</label>
            <input type="number" step="0.01" min="0" max="4.0" name="gpa" value="{{ $formData['academic']['gpa'] ?? '' }}"
                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                placeholder="Enter your GPA (e.g., 3.5)">
        </div>
        <div>
            <label class="block text-sm font-bold text-gray-700 mb-2">Overall Result / Classification</label>
            <select name="result_classification" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500">
                <option value="">Select classification</option>
                <option value="first_class" {{ ($formData['academic']['result_classification'] ?? '') == 'first_class' ? 'selected' : '' }}>First Class Honours</option>
                <option value="upper_second" {{ ($formData['academic']['result_classification'] ?? '') == 'upper_second' ? 'selected' : '' }}>Upper Second Class (2.1)</option>
                <option value="lower_second" {{ ($formData['academic']['result_classification'] ?? '') == 'lower_second' ? 'selected' : '' }}>Lower Second Class (2.2)</option>
                <option value="pass" {{ ($formData['academic']['result_classification'] ?? '') == 'pass' ? 'selected' : '' }}>Pass</option>
                <option value="distinction" {{ ($formData['academic']['result_classification'] ?? '') == 'distinction' ? 'selected' : '' }}>Distinction</option>
                <option value="credit" {{ ($formData['academic']['result_classification'] ?? '') == 'credit' ? 'selected' : '' }}>Credit</option>
            </select>
        </div>
    </div>

    {{-- Additional Info --}}
    <div class="bg-gray-50 rounded-xl p-4 border border-gray-200">
        <h4 class="font-semibold text-gray-700 mb-3 flex items-center">
            <i class="fas fa-info-circle text-gray-500 mr-2"></i>
            Additional Information
        </h4>
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Any Other Relevant Qualifications</label>
            <textarea name="other_qualifications" rows="3" 
                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                placeholder="List any other relevant certifications, short courses, or professional qualifications...">{{ $formData['academic']['other_qualifications'] ?? '' }}</textarea>
        </div>
    </div>
</div>
