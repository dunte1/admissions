<div x-data="{ agreed: false }" class="space-y-6">
    <div class="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-lg p-6">
        <div class="flex items-start">
            <div class="flex-shrink-0 mt-1">
                <i class="fas fa-scroll text-blue-500 text-xl"></i>
            </div>
            <div class="ml-4">
                <h4 class="text-lg font-bold text-gray-900">Declaration & Agreement</h4>
                <p class="text-sm text-gray-600 mt-1">Please read the following terms carefully before submitting your application.</p>
            </div>
        </div>
    </div>

    <div class="space-y-4 max-h-96 overflow-y-auto pr-2">
        <div class="prose prose-sm text-gray-600">
            <h5 class="font-bold text-gray-900">1. Accuracy of Information</h5>
            <p>I declare that all information provided in this application is true, accurate, and complete to the best of my knowledge. I understand that providing false or misleading information may result in the rejection of my application or revocation of admission.</p>
            
            <h5 class="font-bold text-gray-900 mt-4">2. Admission Terms</h5>
            <p>I understand that admission to {{ app_name() }} is competitive and meeting the minimum requirements does not guarantee admission. The college reserves the right to admit or reject any applicant without disclosing reasons.</p>
            
            <h5 class="font-bold text-gray-900 mt-4">3. Fees and Payments</h5>
            <p>I agree to pay all required fees as specified by the college, including tuition, registration, and other applicable charges. I understand that fees are subject to change and that I am responsible for staying informed about current fee structures.</p>
            
            <h5 class="font-bold text-gray-900 mt-4">4. Code of Conduct</h5>
            <p>I agree to abide by all college rules, regulations, and policies, including the student code of conduct. I understand that violation of these rules may result in disciplinary action, including expulsion.</p>
            
            <h5 class="font-bold text-gray-900 mt-4">5. Data Usage</h5>
            <p>I consent to the collection and processing of my personal data by the college for administrative and academic purposes. I understand that my data will be handled in accordance with the college's privacy policy and applicable data protection laws.</p>
            
            <h5 class="font-bold text-gray-900 mt-4">6. Document Authenticity</h5>
            <p>I declare that all documents submitted with this application are authentic and were legally obtained. I understand that submission of forged or fraudulent documents will result in immediate rejection and may lead to legal proceedings.</p>
            
            <h5 class="font-bold text-gray-900 mt-4">7. Updates and Communication</h5>
            <p>I agree to keep my contact information updated and to check my application status regularly. I understand that the college may communicate with me via email, SMS, or the student portal.</p>
        </div>
    </div>

    <div class="border-t border-gray-200 pt-6">
        <label class="flex items-start cursor-pointer group">
            <div class="flex items-center h-6">
                <input type="checkbox" x-model="agreed" required 
                    class="w-5 h-5 text-blue-600 border-gray-300 rounded focus:ring-blue-500">
            </div>
            <div class="ml-3">
                <p class="text-sm text-gray-700">
                    <span class="font-semibold">I have read and agree to the terms and conditions above.</span>
                    <span class="text-red-500"> *</span>
                </p>
                <p class="text-xs text-gray-500 mt-1">By checking this box, you confirm that all information provided is accurate.</p>
            </div>
        </label>
    </div>

    <div class="bg-amber-50 border border-amber-200 rounded-lg p-4 flex items-start">
        <div class="flex-shrink-0">
            <i class="fas fa-exclamation-triangle text-amber-500"></i>
        </div>
        <div class="ml-3">
            <p class="text-sm text-amber-800">
                <strong>Important:</strong> Once you submit your application, you will not be able to make changes. Please review all sections carefully before proceeding.
            </p>
        </div>
    </div>

    <div class="flex items-center justify-between bg-gray-50 rounded-lg p-4">
        <div class="flex items-center">
            <i class="fas fa-shield-alt text-green-500 mr-3 text-xl"></i>
            <div>
                <p class="text-sm font-semibold text-gray-900">Secure Submission</p>
                <p class="text-xs text-gray-500">Your data is protected and encrypted</p>
            </div>
        </div>
        <div x-show="agreed" x-transition class="flex items-center text-green-600">
            <i class="fas fa-check-circle mr-2"></i>
            <span class="text-sm font-medium">Ready to submit</span>
        </div>
        <div x-show="!agreed" x-transition class="flex items-center text-gray-400">
            <i class="fas fa-minus-circle mr-2"></i>
            <span class="text-sm font-medium">Accept terms to continue</span>
        </div>
    </div>
</div>
