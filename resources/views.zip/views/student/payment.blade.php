@extends('layouts.student')

@section('content')
<div class="max-w-4xl mx-auto">
    <div class="mb-8">
        <div class="flex items-center justify-between">
            <div>
                <h1 class="text-3xl font-bold text-gray-900">{{ __('labels.payment') }}</h1>
                <p class="text-gray-600 mt-1">Application #{{ $application->application_number }}</p>
            </div>
            <a href="{{ route('student.dashboard') }}" class="text-gray-500 hover:text-gray-700">
                <i class="fas fa-arrow-left mr-2"></i>Back to Dashboard
            </a>
        </div>
    </div>

    @if(session('success') && session('waiting_payment'))
        <div class="mb-6 bg-green-50 border border-green-200 rounded-xl p-6">
            <div class="flex items-start">
                <div class="flex-shrink-0">
                    <i class="fas fa-check-circle text-green-500 text-2xl"></i>
                </div>
                <div class="ml-4">
                    <h3 class="text-lg font-semibold text-green-800">Payment Request Sent!</h3>
                    <p class="text-green-700 mt-1">{{ session('success') }}</p>
                    <div class="mt-4 p-4 bg-white rounded-lg border border-green-200">
                        <p class="text-sm text-gray-600 mb-3">Check your phone and enter your M-PESA PIN to complete the payment.</p>
                        <button onclick="checkPaymentStatus()" class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 text-sm">
                            <i class="fas fa-sync mr-2"></i>Check Payment Status
                        </button>
                    </div>
                </div>
            </div>
        </div>
    @endif

    @if(session('error'))
        <div class="mb-6 bg-red-50 border border-red-200 rounded-xl p-4 flex items-center">
            <i class="fas fa-exclamation-circle text-red-500 mr-3"></i>
            <p class="text-red-700">{{ session('error') }}</p>
        </div>
    @endif

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div class="lg:col-span-2">
            @if($hasCompletedPayment)
                <div class="bg-white rounded-xl shadow-sm border border-green-200 p-6 mb-6">
                    <div class="flex items-center text-green-600">
                        <i class="fas fa-check-circle text-3xl mr-4"></i>
                        <div>
                            <h3 class="text-xl font-bold">Payment Complete</h3>
                            <p class="text-green-600">Your application fee has been paid.</p>
                        </div>
                    </div>
                </div>
            @else
                <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6">
                    <h2 class="text-xl font-bold text-gray-900 mb-6">Select Payment Method</h2>

                    <div class="space-y-4">
                        <label class="flex items-center p-4 border-2 border-gray-200 rounded-xl cursor-pointer hover:border-blue-300 transition-all payment-option" data-method="mpesa">
                            <input type="radio" name="payment_method" value="mpesa" class="mr-4" required>
                            <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mr-4">
                                <span class="text-xl font-bold text-green-600">M</span>
                            </div>
                            <div class="flex-1">
                                <p class="font-semibold text-gray-900">M-PESA</p>
                                <p class="text-sm text-gray-500">Pay instantly via mobile money</p>
                            </div>
                        </label>

                        <label class="flex items-center p-4 border-2 border-gray-200 rounded-xl cursor-pointer hover:border-blue-300 transition-all payment-option opacity-50" data-method="paypal">
                            <input type="radio" name="payment_method" value="paypal" class="mr-4" disabled>
                            <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mr-4">
                                <span class="text-xl font-bold text-blue-600">PP</span>
                            </div>
                            <div class="flex-1">
                                <p class="font-semibold text-gray-900">PayPal</p>
                                <p class="text-sm text-gray-500">Coming soon</p>
                            </div>
                            <span class="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded">Soon</span>
                        </label>
                    </div>

                    <form action="{{ route('student.payment.initiate', $application->id) }}" method="POST" id="payment-form" class="mt-6">
                        @csrf
                        <input type="hidden" name="payment_method" id="selected-method" value="mpesa">

                        <div id="mpesa-fields" class="space-y-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">M-PESA Phone Number</label>
                                <div class="relative">
                                    <span class="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">+254</span>
                                    <input type="tel" name="phone" placeholder="712345678" 
                                        class="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                        pattern="[0-9]{9}" maxlength="9" required>
                                </div>
                                <p class="text-xs text-gray-500 mt-1">Enter 9 digits after 254 (e.g., 712345678)</p>
                            </div>
                        </div>

                        <button type="submit" class="w-full mt-6 bg-green-600 text-white py-4 rounded-lg hover:bg-green-700 transition-all font-semibold text-lg">
                            <i class="fas fa-mobile-alt mr-2"></i>
                            Pay KES {{ number_format($applicationFee) }} via M-PESA
                        </button>
                    </form>
                </div>
            @endif

            @if($pendingPayment)
                <div class="bg-yellow-50 border border-yellow-200 rounded-xl p-6">
                    <h3 class="font-semibold text-yellow-800 mb-2">
                        <i class="fas fa-clock mr-2"></i>Pending Payment
                    </h3>
                    <p class="text-sm text-yellow-700 mb-4">Transaction ID: {{ $pendingPayment->transaction_id }}</p>
                    <button onclick="checkPaymentStatus()" class="bg-yellow-600 text-white px-4 py-2 rounded-lg hover:bg-yellow-700">
                        Check Status
                    </button>
                </div>
            @endif
        </div>

        <div class="lg:col-span-1">
            <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 sticky top-4">
                <h3 class="text-lg font-bold text-gray-900 mb-4">Payment Summary</h3>
                
                <div class="space-y-4">
                    <div class="flex justify-between">
                        <span class="text-gray-600">Application Number</span>
                        <span class="font-medium">{{ $application->application_number }}</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-gray-600">Program</span>
                        <span class="font-medium text-right">{{ $application->program->name ?? 'N/A' }}</span>
                    </div>
                    <hr class="border-gray-200">
                    <div class="flex justify-between text-lg">
                        <span class="font-semibold">Total Amount</span>
                        <span class="font-bold text-[#00008B]">KES {{ number_format($applicationFee) }}</span>
                    </div>
                </div>

                <div class="mt-6 p-4 bg-gray-50 rounded-lg">
                    <h4 class="text-sm font-semibold text-gray-700 mb-2">How to Pay via M-PESA</h4>
                    <ol class="text-xs text-gray-600 space-y-1">
                        <li>1. Select M-PESA as payment method</li>
                        <li>2. Enter your phone number (starting with 254)</li>
                        <li>3. Click Pay and wait for M-PESA prompt</li>
                        <li>4. Enter your M-PESA PIN on your phone</li>
                        <li>5. Confirm payment on this page</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    @if($payments->count() > 0)
        <div class="mt-8">
            <h3 class="text-lg font-bold text-gray-900 mb-4">Payment History</h3>
            <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <table class="w-full">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Method</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Amount</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Receipt</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        @foreach($payments as $payment)
                            <tr>
                                <td class="px-6 py-4 text-sm text-gray-900">
                                    {{ $payment->created_at->format('M d, Y h:i A') }}
                                </td>
                                <td class="px-6 py-4 text-sm text-gray-900 capitalize">
                                    {{ ucfirst($payment->payment_method) }}
                                </td>
                                <td class="px-6 py-4 text-sm font-medium text-gray-900">
                                    KES {{ number_format($payment->amount, 2) }}
                                </td>
                                <td class="px-6 py-4">
                                    <span class="px-2 py-1 text-xs rounded-full {{ $payment->getStatusBadgeClass() }}">
                                        {{ ucfirst($payment->status) }}
                                    </span>
                                </td>
                                <td class="px-6 py-4 text-sm text-gray-500">
                                    {{ $payment->mpesa_receipt ?? '-' }}
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    @endif
</div>

@if($pendingPayment)
<div id="status-modal" class="fixed inset-0 bg-black bg-opacity-50 hidden items-center justify-center z-50">
    <div class="bg-white rounded-xl p-6 max-w-md mx-4">
        <div id="status-content" class="text-center">
            <div class="animate-spin w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full mx-auto mb-4"></div>
            <p class="text-gray-600">Checking payment status...</p>
        </div>
    </div>
</div>
@endif

@endsection

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    const paymentOptions = document.querySelectorAll('.payment-option');
    
    paymentOptions.forEach(option => {
        option.addEventListener('click', function() {
            const method = this.dataset.method;
            if (method === 'paypal') return;
            
            paymentOptions.forEach(opt => opt.classList.remove('border-blue-500', 'bg-blue-50'));
            this.classList.add('border-blue-500', 'bg-blue-50');
            document.getElementById('selected-method').value = method;
        });
    });

    @if($hasCompletedPayment)
    @else
    paymentOptions[0].classList.add('border-blue-500', 'bg-blue-50');
    @endif
});

@if($pendingPayment)
function checkPaymentStatus() {
    const modal = document.getElementById('status-modal');
    const content = document.getElementById('status-content');
    
    modal.classList.remove('hidden');
    modal.classList.add('flex');
    content.innerHTML = `
        <div class="animate-spin w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full mx-auto mb-4"></div>
        <p class="text-gray-600">Checking payment status...</p>
    `;
    
    fetch('{{ route('student.payment.check-status', $application->id) }}')
        .then(response => response.json())
        .then(data => {
            if (data.status === 'completed') {
                content.innerHTML = `
                    <div class="text-green-500 text-6xl mb-4"><i class="fas fa-check-circle"></i></div>
                    <h3 class="text-xl font-bold text-gray-900 mb-2">Payment Successful!</h3>
                    <p class="text-gray-600">Receipt: ${data.receipt || 'N/A'}</p>
                    <a href="{{ route('student.dashboard') }}" class="inline-block mt-4 bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">
                        Return to Dashboard
                    </a>
                `;
                setTimeout(() => location.reload(), 2000);
            } else if (data.status === 'failed') {
                content.innerHTML = `
                    <div class="text-red-500 text-6xl mb-4"><i class="fas fa-times-circle"></i></div>
                    <h3 class="text-xl font-bold text-gray-900 mb-2">Payment Failed</h3>
                    <p class="text-gray-600">${data.message}</p>
                    <button onclick="closeModal()" class="mt-4 bg-gray-600 text-white px-6 py-2 rounded-lg hover:bg-gray-700">
                        Try Again
                    </button>
                `;
            } else {
                content.innerHTML = `
                    <div class="text-yellow-500 text-6xl mb-4"><i class="fas fa-clock"></i></div>
                    <h3 class="text-xl font-bold text-gray-900 mb-2">Still Processing</h3>
                    <p class="text-gray-600">${data.message}</p>
                    <button onclick="checkPaymentStatus()" class="mt-4 bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700">
                        Check Again
                    </button>
                `;
            }
        })
        .catch(error => {
            content.innerHTML = `
                <div class="text-red-500 text-6xl mb-4"><i class="fas fa-exclamation-triangle"></i></div>
                <h3 class="text-xl font-bold text-gray-900 mb-2">Error</h3>
                <p class="text-gray-600">Failed to check payment status</p>
                <button onclick="closeModal()" class="mt-4 bg-gray-600 text-white px-6 py-2 rounded-lg hover:bg-gray-700">
                    Close
                </button>
            `;
        });
}

function closeModal() {
    document.getElementById('status-modal').classList.add('hidden');
    document.getElementById('status-modal').classList.remove('flex');
}

// Auto-check status every 5 seconds
@if(session('waiting_payment'))
setInterval(checkPaymentStatus, 5000);
@endif
@endif
</script>
@endpush
