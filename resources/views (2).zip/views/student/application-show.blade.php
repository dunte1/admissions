@extends('layouts.student')

@section('content')
<div class="max-w-5xl mx-auto">
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6 sm:mb-8">
        <div>
            <h1 class="text-2xl sm:text-3xl font-bold text-gray-900">{{ $application->application_number }}</h1>
            <p class="text-gray-500 mt-1">{{ $application->program->name ?? 'N/A' }}</p>
        </div>
        <span class="px-4 py-2 text-sm rounded-full w-fit {{ $application->getStatusBadgeClass() }}">
            {{ ucfirst(str_replace('_', ' ', $application->status)) }}
        </span>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6">
        <div class="lg:col-span-2 space-y-4 sm:space-y-6">
            <div class="bg-white rounded-xl shadow-sm p-4 sm:p-6">
                <h2 class="text-lg font-semibold mb-4">{{ __('labels.application_details') }}</h2>
                
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6">
                    <div>
                        <h3 class="text-sm font-medium text-gray-500">Program</h3>
                        <p class="text-gray-900 font-medium">{{ $application->program->name ?? 'N/A' }}</p>
                    </div>
                    <div>
                        <h3 class="text-sm font-medium text-gray-500">Level</h3>
                        <p class="text-gray-900">{{ ucfirst($application->program->level ?? 'N/A') }}</p>
                    </div>
                    <div>
                        <h3 class="text-sm font-medium text-gray-500">Applied Date</h3>
                        <p class="text-gray-900">{{ $application->created_at->format('M d, Y') }}</p>
                    </div>
                    <div>
                        <h3 class="text-sm font-medium text-gray-500">Status</h3>
                        <p class="text-gray-900">{{ ucfirst(str_replace('_', ' ', $application->status)) }}</p>
                    </div>
                </div>

                @if($application->review_notes)
                <div class="mt-4 sm:mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <h3 class="text-sm font-medium text-yellow-800">Review Notes</h3>
                    <p class="text-sm text-yellow-700 mt-1">{{ $application->review_notes }}</p>
                </div>
                @endif
            </div>

            <div class="bg-white rounded-xl shadow-sm p-4 sm:p-6">
                <h2 class="text-lg font-semibold mb-4">{{ __('labels.payment_history') }}</h2>
                
                @if($application->payments->isEmpty())
                    <p class="text-gray-500 text-center py-4">No payments recorded</p>
                @else
                    <div class="overflow-x-auto">
                        <table class="w-full">
                            <thead>
                                <tr class="text-left text-sm text-gray-500">
                                    <th class="pb-2">Date</th>
                                    <th class="pb-2">Method</th>
                                    <th class="pb-2">Amount</th>
                                    <th class="pb-2">Status</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y">
                                @foreach($application->payments as $payment)
                                <tr>
                                    <td class="py-3 sm:py-2 text-sm">{{ $payment->created_at->format('M d, Y') }}</td>
                                    <td class="py-3 sm:py-2 text-sm capitalize">{{ $payment->payment_method }}</td>
                                    <td class="py-3 sm:py-2 text-sm">KES {{ number_format($payment->amount, 2) }}</td>
                                    <td class="py-3 sm:py-2">
                                        <span class="px-2 py-1 text-xs rounded-full {{ $payment->getStatusBadgeClass() }}">
                                            {{ ucfirst($payment->status) }}
                                        </span>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                @endif
            </div>
        </div>

        <div class="space-y-4 sm:space-y-6">
            <div class="bg-white rounded-xl shadow-sm p-4 sm:p-6">
                <h3 class="text-lg font-semibold mb-4">{{ __('labels.quick_actions') }}</h3>
                
                @if($application->status === 'draft')
                    <a href="{{ route('student.application.form', ['step' => $application->current_step ?? 'personal']) }}" 
                       class="block w-full bg-purple-600 text-white text-center py-3 rounded-lg hover:bg-purple-700 mb-3 font-medium">
                        Continue Application
                    </a>
                @endif

                @if($application->status === 'draft' && !$application->payments->where('status', 'completed')->exists())
                    <a href="{{ route('student.payment.show', $application->id) }}" 
                       class="block w-full bg-green-600 text-white text-center py-3 rounded-lg hover:bg-green-700 mb-3 font-medium">
                        Pay Application Fee
                    </a>
                @endif

                <a href="#" class="block w-full bg-gray-100 text-gray-700 text-center py-3 rounded-lg hover:bg-gray-200 font-medium">
                    Download Receipt
                </a>
            </div>

            <div class="bg-white rounded-xl shadow-sm p-4 sm:p-6">
                <h3 class="text-lg font-semibold mb-4">{{ __('labels.need_help') }}</h3>
                <p class="text-sm text-gray-600 mb-4">
                    Contact our admissions office for assistance with your application.
                </p>
                <div class="space-y-2 text-sm">
                    <p>
                        <strong class="text-gray-900">Email:</strong> 
                        <a href="mailto:{{ system_setting('contact_email', 'support@example.com') }}" class="text-[#00008B] hover:underline">
                            {{ system_setting('contact_email', 'support@example.com') }}
                        </a>
                    </p>
                    <p>
                        <strong class="text-gray-900">Phone:</strong> 
                        <a href="tel:{{ system_setting('contact_phone', '+254700000000') }}" class="text-[#00008B] hover:underline">
                            {{ system_setting('contact_phone', '+254 700 000 000') }}
                        </a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
