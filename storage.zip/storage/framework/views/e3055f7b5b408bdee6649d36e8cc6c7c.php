<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="description" content="<?php echo e(system_setting('tagline', 'Streamline Admissions for Schools, Colleges & Universities')); ?>">
    <title><?php echo $__env->yieldContent('title', system_setting('system_name', 'Admission Portal') . ' - Admission Portal'); ?></title>
    <link rel="icon" href="<?php echo e(app_favicon()); ?>">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { font-family: 'Inter', sans-serif; }
        :root {
            --primary-color: <?php echo e(system_setting('primary_color', '#7C3AED')); ?>;
            --secondary-color: <?php echo e(system_setting('secondary_color', '#10B981')); ?>;
        }
        html { scroll-behavior: smooth; }
        [x-cloak] { display: none !important; }
    </style>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body class="min-h-screen">
    <?php echo $__env->yieldContent('content'); ?>
    <script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
    <?php if (isset($component)) { $__componentOriginal5328599bca5168b09e700e7f36fada50 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5328599bca5168b09e700e7f36fada50 = $attributes; } ?>
<?php $component = App\View\Components\AiChatWidget::resolve(['mode' => 'sales'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ai-chat-widget'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AiChatWidget::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5328599bca5168b09e700e7f36fada50)): ?>
<?php $attributes = $__attributesOriginal5328599bca5168b09e700e7f36fada50; ?>
<?php unset($__attributesOriginal5328599bca5168b09e700e7f36fada50); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5328599bca5168b09e700e7f36fada50)): ?>
<?php $component = $__componentOriginal5328599bca5168b09e700e7f36fada50; ?>
<?php unset($__componentOriginal5328599bca5168b09e700e7f36fada50); ?>
<?php endif; ?>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\Users\dunth\Desktop\projects\admission-portal\resources\views/layouts/guest.blade.php ENDPATH**/ ?>